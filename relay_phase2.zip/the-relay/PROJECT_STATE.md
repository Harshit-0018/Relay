# Project State — The Relay

## Current phase
Phase 2 implementation complete; proceed to Phase 3.

## Implemented in Phase 1
- Exact-version paper registry for `1706.03762v7`, `2410.00037v1` and `2507.07955v2`.
- Version-pinned arXiv PDF downloader with PDF-signature validation and SHA-256 manifest generation.
- PyMuPDF page extraction with 1-based physical PDF page metadata and conservative section detection.
- Page-bounded chunking with configurable character size/overlap and deterministic chunk IDs.
- Dependency-free BM25 retriever and callable `search_research_papers` tool.
- CLI commands for paper ingestion and retrieval search.
- 20 initial evaluation questions.
- BM25 ranking ignores common stop words to reduce function-word-only false matches; public text tokenizer remains unchanged.

## Implemented in Phase 2
- FastAPI service with `/health`, `/v1/ask`, `/v1/ask/stream` and `/docs`.
- Provider abstraction with async Groq Chat Completions integration and offline deterministic demo provider.
- Configurable model, endpoint, timeouts, token budget, top-k and context limit through `.env`.
- Actual retrieval tool invocation from the answer pipeline.
- Bounded evidence context with exact paper/version/physical-page citation labels.
- Evidence-only system prompt and deterministic citation-provenance verification.
- At most one correction attempt by default; invalid/unverifiable drafts are withheld.
- Refusal when retrieval returns no matching passages.
- Upstream model streaming is buffered until citation verification completes, then delivered as SSE chunks.
- Groq adapter defaults to `openai/gpt-oss-20b`; the model is configurable.

## Verification
- Phase 2 test suite: 22 passed, 0 failed, 0 skipped (see `tests/TEST_STATUS.md`).
- Python compilation passed.
- FastAPI JSON endpoint, health endpoint and SSE endpoint exercised through local tests.
- Pipeline tests cover no-match refusal, demo mode, one bounded correction and withholding after citation failure.
- No live Groq request was made because no user API key was supplied.
- The exact paper PDFs are still not embedded; local download and ingestion are required before substantive queries.

## Paper downloads
The exact versioned URLs are recorded in `data/papers/paper_registry.json`. Earlier build environment was unable to resolve `arxiv.org`; run `python scripts/download_papers.py` locally, then `python -m app.cli ingest`.

## Known limitations
- Printed page labels are not parsed reliably; `pdf_page` is the 1-based physical PDF page index and current citation basis.
- Section detection is heuristic and best-effort.
- BM25 is lexical. Hybrid retrieval, reranking and configuration comparisons are Phase 4.
- Citation validation verifies reference provenance, not semantic entailment of every generated claim.
- Demo mode tests pipeline wiring only; it is not an LLM or substantive answer generator.
- Streaming deliberately withholds text until the complete upstream draft has passed citation validation. First client chunk therefore comes after generation/verification.
- Reliability controls and configurable load-aware stand-in are Phase 3.

## Local start
1. `pip install -r requirements.txt`
2. `python scripts/download_papers.py`
3. `python -m app.cli ingest`
4. Copy `.env.example` to `.env`; keep `PROVIDER_MODE=demo` for offline mode or set `PROVIDER_MODE=groq` and add `GROQ_API_KEY`.
5. `uvicorn app.main:app --reload`

## Next phase
Phase 3: configurable stand-in model service, queueing/admission controls, concurrency, rate limiting, retries/backoff, timeouts, cancellation and graceful degradation.
