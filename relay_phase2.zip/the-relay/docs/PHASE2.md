# Phase 2 implementation notes

## Implemented

- FastAPI application: `app.main:app`
- `POST /v1/ask` for standard JSON responses
- `POST /v1/ask/stream` for server-sent events
- `GET /health` and Swagger UI at `/docs`
- Provider interface with a Groq adapter and a deterministic offline demo adapter
- Grounded system prompt that treats retrieved paper text as untrusted evidence, not instructions
- Actual `PaperSearchTool` invocation inside the pipeline
- Context limits and exact source citation labels
- Citation provenance validation against retrieved references
- One bounded correction attempt by default
- Refusal when retrieval has no match or citation validation fails
- Verified-before-delivery streaming: provider output is buffered and validated before SSE text is released

## Provider configuration

Set `PROVIDER_MODE=demo` for offline wiring tests. Set `PROVIDER_MODE=groq`, `GROQ_API_KEY`, and optionally `GROQ_MODEL` for hosted generation. The current default is `openai/gpt-oss-20b`; the model ID can be changed in `.env` without changing code.

## Verification boundary

`CitationVerifier` confirms that citations in the answer exactly match retrieved paper/version/page labels. It is not a semantic entailment model and does not establish that every claim is fully supported. The prompt requires evidence-only answers; quality and semantic grounding are to be measured in Phase 4.

## Streaming boundary

The Groq adapter supports upstream SSE. The pipeline consumes the stream, assembles the draft, verifies citations, then exposes the verified answer in response chunks. This intentionally trades earlier client TTFT for check-before-send safety. Response metadata reports `verification_before_delivery: true`.

## Phase 3 follow-on

The current API does not yet include production queueing, admission control, retries/backoff, circuit breaking or a load-aware local simulator. Those are Phase 3 items.
