# Phase 1 — Paper ingestion and retrieval

Implemented:
- Exact arXiv versions pinned in `data/papers/paper_registry.json`.
- PDF downloader with signature validation and SHA-256 manifest.
- Physical-page text extraction and best-effort section detection.
- Page-bounded character chunking with deterministic IDs.
- Dependency-free BM25 retrieval and callable paper search tool.
- Starter evaluation questions.

Run `python scripts/download_papers.py`, then `python -m app.cli ingest`. See the root README for local commands.
