from app.retrieval.bm25 import BM25Retriever
from app.retrieval.schemas import Chunk


def make_chunk(chunk_id: str, text: str, page: int) -> Chunk:
    return Chunk(chunk_id, "p", "Paper", "1234.00001", 1, "paper.pdf", page, None, "Section", 0, text)


def test_bm25_ranks_relevant_chunk_first():
    chunks = [
        make_chunk("a", "The transformer uses self attention for sequence modeling", 1),
        make_chunk("b", "Attention mechanisms are used in machine learning", 2),
    ]
    results = BM25Retriever(chunks).search("transformer self attention", top_k=2)
    assert results[0].chunk.chunk_id == "a"
    assert results[0].score > results[1].score


def test_bm25_empty_query_returns_no_results():
    assert BM25Retriever([make_chunk("a", "some text", 1)]).search("   ") == []


def test_bm25_ignores_function_word_only_matches():
    chunks = [make_chunk("transformer", "The Transformer relies on self attention.", 1)]
    retriever = BM25Retriever(chunks)
    assert retriever.search("What is the capital of France?") == []
