from app.services.citations import CitationVerifier, citation_label


def test_citation_verifier_accepts_exact_retrieved_reference():
    allowed = ["[Paper A, arXiv:1234.5678v1, PDF p. 3, section: 1 Intro]"]
    answer = "The method is described here. " + allowed[0]
    result = CitationVerifier().verify(answer, allowed)
    assert result.valid is True
    assert result.citations == allowed


def test_citation_verifier_rejects_unknown_reference():
    allowed = ["[Paper A, arXiv:1234.5678v1, PDF p. 3, section: 1 Intro]"]
    result = CitationVerifier().verify("Claim [Paper B, arXiv:0000.0000v1, PDF p. 9].", allowed)
    assert result.valid is False


def test_citation_verifier_rejects_missing_reference():
    result = CitationVerifier().verify("There is no source citation.", [])
    assert result.valid is False


def test_citation_label_uses_physical_page_and_fallback_section():
    label = citation_label({
        "title": "Paper A", "arxiv_id": "1234.5678", "version": 2,
        "pdf_page": 4, "section": None,
    })
    assert label == "[Paper A, arXiv:1234.5678v2, PDF p. 4, section: section unavailable]"
