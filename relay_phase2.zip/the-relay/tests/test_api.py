from pathlib import Path

from fastapi.testclient import TestClient

from app.api import create_app
from app.config import Settings
from app.providers.demo_provider import DemoProvider
from app.retrieval.schemas import Chunk
from app.retrieval.store import save_chunks
from app.retrieval.tool import PaperSearchTool
from app.services.pipeline import PaperQAPipeline


def make_test_app(tmp_path: Path):
    chunk = Chunk(
        chunk_id="chunk-1", paper_id="attention", title="Attention Is All You Need",
        arxiv_id="1706.03762", version=7, pdf_filename="1706.03762v7.pdf",
        pdf_page=3, printed_page=None, section="1 Introduction", chunk_index_on_page=0,
        text="The Transformer architecture relies entirely on attention mechanisms and does not use recurrence.",
    )
    chunks_path = tmp_path / "chunks.jsonl"
    save_chunks(chunks_path, [chunk])
    settings = Settings(provider_mode="demo", chunks_path=chunks_path)
    pipeline = PaperQAPipeline(PaperSearchTool(chunks_path), DemoProvider(), settings)
    return create_app(pipeline=pipeline, settings=settings)


def test_ask_endpoint_returns_verified_response(tmp_path):
    client = TestClient(make_test_app(tmp_path))
    response = client.post("/v1/ask", json={"question": "What does the Transformer rely on?"})
    assert response.status_code == 200
    body = response.json()
    assert body["provider"] == "demo"
    assert body["refused"] is False
    assert body["citations"]


def test_stream_endpoint_sends_verified_answer_events(tmp_path):
    client = TestClient(make_test_app(tmp_path))
    response = client.post("/v1/ask/stream", json={"question": "What does the Transformer rely on?"})
    assert response.status_code == 200
    assert "verification_before_delivery" in response.text
    assert '"type": "token"' in response.text
    assert '"type": "done"' in response.text


def test_health_endpoint(tmp_path):
    client = TestClient(make_test_app(tmp_path))
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["paper_library_ready"] is True
