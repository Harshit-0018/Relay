from pathlib import Path

import pytest

from app.config import Settings
from app.providers.base import CompletionResult
from app.providers.demo_provider import DemoProvider
from app.retrieval.schemas import Chunk
from app.retrieval.store import save_chunks
from app.retrieval.tool import PaperSearchTool
from app.services.pipeline import PaperQAPipeline


class SequenceProvider:
    name = "fake"
    model = "fake-model"

    def __init__(self, outputs):
        self.outputs = list(outputs)
        self.calls = 0

    async def complete(self, messages, *, temperature, max_completion_tokens):
        del messages, temperature, max_completion_tokens
        self.calls += 1
        return CompletionResult(content=self.outputs.pop(0), model=self.model, input_tokens=11, output_tokens=7)

    async def stream(self, messages, *, temperature, max_completion_tokens):
        result = await self.complete(messages, temperature=temperature, max_completion_tokens=max_completion_tokens)
        for piece in result.content.split(" "):
            yield piece + " "


def make_pipeline(tmp_path: Path, provider):
    chunk = Chunk(
        chunk_id="chunk-1", paper_id="attention", title="Attention Is All You Need",
        arxiv_id="1706.03762", version=7, pdf_filename="1706.03762v7.pdf",
        pdf_page=3, printed_page=None, section="1 Introduction", chunk_index_on_page=0,
        text="The Transformer architecture relies entirely on attention mechanisms and does not use recurrence.",
    )
    chunks_path = tmp_path / "chunks.jsonl"
    save_chunks(chunks_path, [chunk])
    settings = Settings(provider_mode="demo", chunks_path=chunks_path, max_correction_attempts=1)
    return PaperQAPipeline(PaperSearchTool(chunks_path), provider, settings)


@pytest.mark.asyncio
async def test_pipeline_refuses_when_retrieval_has_no_match(tmp_path):
    pipeline = make_pipeline(tmp_path, DemoProvider())
    result = await pipeline.answer("What is the capital of France?")
    assert result.refused is True
    assert result.verification_status == "refused_no_evidence"
    assert result.citations == []


@pytest.mark.asyncio
async def test_pipeline_returns_demo_retrieval_check_with_valid_citation(tmp_path):
    pipeline = make_pipeline(tmp_path, DemoProvider())
    result = await pipeline.answer("What does the Transformer rely on?")
    assert result.refused is False
    assert result.provider == "demo"
    assert result.citations
    assert "not a model-generated answer" in result.answer


@pytest.mark.asyncio
async def test_pipeline_runs_one_bounded_correction(tmp_path):
    citation = "[Attention Is All You Need, arXiv:1706.03762v7, PDF p. 3, section: 1 Introduction]"
    provider = SequenceProvider(["Unsupported draft without a citation.", f"The model uses attention. {citation}"])
    pipeline = make_pipeline(tmp_path, provider)
    result = await pipeline.answer("What does the Transformer rely on?")
    assert result.refused is False
    assert result.correction_attempts == 1
    assert provider.calls == 2
    assert result.citations == [citation]


@pytest.mark.asyncio
async def test_pipeline_withholds_answer_after_invalid_correction(tmp_path):
    provider = SequenceProvider(["No citation.", "Still no source."])
    pipeline = make_pipeline(tmp_path, provider)
    result = await pipeline.answer("What does the Transformer rely on?")
    assert result.refused is True
    assert result.verification_status == "refused_citation_validation_failed"
    assert provider.calls == 2
