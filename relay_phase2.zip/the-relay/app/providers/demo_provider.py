from __future__ import annotations

import re
from collections.abc import AsyncIterator

from app.providers.base import CompletionResult


class DemoProvider:
    """Deterministic offline provider for wiring and citation-flow checks, not an LLM."""

    name = "demo"
    model = "demo-retrieval-check"

    @staticmethod
    def _make_response(messages: list[dict[str, str]]) -> str:
        user_text = next((message.get("content", "") for message in reversed(messages) if message.get("role") == "user"), "")
        match = re.search(r"^\[E\d+\] (\[.*?\])$", user_text, flags=re.MULTILINE)
        if not match:
            return "DEMO MODE: No citation-bearing evidence was included. This is not a model-generated answer."
        citation = match.group(1)
        return (
            "DEMO MODE: The retrieval pipeline found a potentially relevant passage in the paper library. "
            "This response confirms retrieval and citation wiring only; it is not a model-generated answer "
            f"and should not be treated as a substantive answer. {citation} "
            "Set PROVIDER_MODE=groq and configure GROQ_API_KEY for model-generated answers."
        )

    async def complete(self, messages, *, temperature: float, max_completion_tokens: int) -> CompletionResult:
        del temperature, max_completion_tokens
        return CompletionResult(content=self._make_response(messages), model=self.model)

    async def stream(self, messages, *, temperature: float, max_completion_tokens: int) -> AsyncIterator[str]:
        result = await self.complete(
            messages, temperature=temperature, max_completion_tokens=max_completion_tokens
        )
        words = result.content.split(" ")
        for index, word in enumerate(words):
            yield word if index == len(words) - 1 else word + " "
