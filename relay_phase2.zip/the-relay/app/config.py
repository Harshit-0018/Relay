from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_dotenv() -> None:
    """Load .env when python-dotenv is installed; environment always wins."""
    try:
        from dotenv import load_dotenv

        load_dotenv(ROOT / ".env", override=False)
    except ImportError:
        return


@dataclass(frozen=True, slots=True)
class Settings:
    provider_mode: str = "demo"
    groq_api_key: str = ""
    groq_model: str = "openai/gpt-oss-20b"
    groq_base_url: str = "https://api.groq.com/openai/v1"
    request_timeout_seconds: float = 45.0
    temperature: float = 0.1
    max_completion_tokens: int = 800
    default_top_k: int = 5
    max_top_k: int = 8
    max_context_chars: int = 14000
    max_correction_attempts: int = 1
    chunks_path: Path = ROOT / "data" / "processed" / "chunks.jsonl"

    @classmethod
    def from_env(cls) -> "Settings":
        _load_dotenv()
        mode = os.getenv("PROVIDER_MODE", "demo").strip().lower()
        if mode not in {"demo", "groq"}:
            raise ValueError("PROVIDER_MODE must be either 'demo' or 'groq'")
        return cls(
            provider_mode=mode,
            groq_api_key=os.getenv("GROQ_API_KEY", "").strip(),
            groq_model=os.getenv("GROQ_MODEL", "openai/gpt-oss-20b").strip(),
            groq_base_url=os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1").rstrip("/"),
            request_timeout_seconds=float(os.getenv("REQUEST_TIMEOUT_SECONDS", "45")),
            temperature=float(os.getenv("MODEL_TEMPERATURE", "0.1")),
            max_completion_tokens=int(os.getenv("MAX_COMPLETION_TOKENS", "800")),
            default_top_k=int(os.getenv("DEFAULT_TOP_K", "5")),
            max_top_k=int(os.getenv("MAX_TOP_K", "8")),
            max_context_chars=int(os.getenv("MAX_CONTEXT_CHARS", "14000")),
            max_correction_attempts=int(os.getenv("MAX_CORRECTION_ATTEMPTS", "1")),
            chunks_path=Path(os.getenv("CHUNKS_PATH", str(ROOT / "data" / "processed" / "chunks.jsonl"))),
        )
