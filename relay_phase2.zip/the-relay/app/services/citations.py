from __future__ import annotations

import re
from dataclasses import dataclass

_CITATION_PATTERN = re.compile(r"\[[^\]\n]*arxiv:[^\]\n]*\]", flags=re.IGNORECASE)


@dataclass(slots=True)
class CitationCheck:
    valid: bool
    citations: list[str]
    errors: list[str]


class CitationVerifier:
    """Verifies citation provenance against the exact labels supplied to the model.

    This is deliberately not described as semantic entailment verification. It confirms
    that cited paper/page references came from retrieved chunks; it cannot prove that
    every natural-language claim is entailed by the passage.
    """

    def verify(self, answer: str, allowed_citations: list[str]) -> CitationCheck:
        allowed = set(allowed_citations)
        found = _CITATION_PATTERN.findall(answer or "")
        if not found:
            return CitationCheck(False, [], ["No paper citation was found in the answer."])
        invalid = [citation for citation in found if citation not in allowed]
        if invalid:
            return CitationCheck(False, [], ["Answer contains a citation not present in retrieved evidence."])
        unique: list[str] = []
        for citation in found:
            if citation not in unique:
                unique.append(citation)
        return CitationCheck(True, unique, [])


def citation_label(chunk: dict) -> str:
    section = chunk.get("section") or "section unavailable"
    return (
        f"[{chunk['title']}, arXiv:{chunk['arxiv_id']}v{chunk['version']}, "
        f"PDF p. {chunk['pdf_page']}, section: {section}]"
    )
