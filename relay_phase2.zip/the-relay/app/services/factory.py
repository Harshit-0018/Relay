from __future__ import annotations

from app.config import Settings
from app.providers.demo_provider import DemoProvider
from app.providers.groq_provider import GroqProvider
from app.retrieval.tool import PaperSearchTool
from app.services.pipeline import PaperQAPipeline


def create_pipeline(settings: Settings | None = None) -> PaperQAPipeline:
    settings = settings or Settings.from_env()
    if settings.provider_mode == "groq":
        provider = GroqProvider(
            api_key=settings.groq_api_key,
            model=settings.groq_model,
            base_url=settings.groq_base_url,
            timeout_seconds=settings.request_timeout_seconds,
        )
    else:
        provider = DemoProvider()
    retrieval_tool = PaperSearchTool(settings.chunks_path)
    return PaperQAPipeline(retrieval_tool, provider, settings)
