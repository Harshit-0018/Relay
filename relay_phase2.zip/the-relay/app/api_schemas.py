from __future__ import annotations

from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=4000)
    top_k: int | None = Field(default=None, ge=1, le=8)


class AskResponse(BaseModel):
    request_id: str
    question: str
    answer: str
    citations: list[str]
    refused: bool
    provider: str
    model: str
    retrieved_chunks: int
    correction_attempts: int
    verification_status: str
    input_tokens: int | None
    output_tokens: int | None
    retrieval_ms: float
    generation_ms: float
    total_ms: float
