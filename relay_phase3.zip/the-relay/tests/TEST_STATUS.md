# Test Status — Cumulative Phases 1–3

Last executed in the build environment with Python 3.13.5, pytest 9.0.2, PyMuPDF 1.26.7, FastAPI and HTTPX.

- **Passed:** 41
- **Failed:** 0
- **Skipped:** 0
- Python compilation (`python -m compileall -q app simulator scripts tests`): passed
- CLI smoke test (`python -m app.cli --help`): passed
- Retry amplification demonstration (`python scripts/retry_storm_demo.py`): completed; no-retry case produced 0 rate-limited calls, retry case produced 1 rate-limited call under the deliberately constrained test budget.

Coverage includes:

- Phase 1 text processing, PDF ingestion fixtures, page-aware chunking, BM25 retrieval, tool contract and evaluation dataset.
- Phase 2 pipeline no-match refusal, demo answer, bounded correction, citation withholding, FastAPI health/JSON/SSE endpoints.
- Phase 3 stand-in completion and streaming, simulated RPM/TPM/daily request/daily token/concurrency quotas, deterministic timeouts, transient retry, non-retryable daily exhaustion, overall deadline, bounded queue rejection, cancellation cleanup, circuit open/half-open recovery, simulator standalone API, reliability metrics and full pipeline use in stand-in mode without Groq credentials.

Not executed:

- Live Groq API calls (no user API key supplied).
- Real Groq rate-limit observation or calibration.
- Download of original arXiv PDFs in this build environment (outbound DNS to arxiv.org was unavailable earlier). Download and ingest locally before substantive paper queries.

Reproduce locally from the `the-relay` project root:

```powershell
python -m pytest -v
python -m compileall -q app simulator scripts tests
python scripts/retry_storm_demo.py
```

No test failures were skipped or hidden.
