# Project State — The Relay

## Current phase

**Phase 3 implementation complete.** The cumulative codebase contains Phase 1, Phase 2 and Phase 3. Next: Phase 4 benchmarking and result generation.

## Phase 1 — Implemented and retained

- Exact-version paper registry for `1706.03762v7`, `2410.00037v1` and `2507.07955v2`.
- Version-pinned arXiv PDF downloader with PDF-signature validation and SHA-256 manifest generation.
- PyMuPDF page extraction with 1-based physical PDF page metadata and conservative section detection.
- Page-bounded chunking with configurable character size/overlap and deterministic chunk IDs.
- Dependency-free BM25 retriever and callable `search_research_papers` tool.
- CLI commands for paper ingestion and retrieval search.
- 20 initial evaluation questions.

## Phase 2 — Implemented and retained

- FastAPI service with `/health`, `/v1/ask`, `/v1/ask/stream` and `/docs`.
- Groq Chat Completions adapter and deterministic offline demo provider.
- Actual retrieval-tool invocation from the answer pipeline.
- Evidence-only prompt, bounded context and source/page citation labels.
- Citation provenance checks, bounded correction and refusal paths.
- Verified-before-delivery streaming: full draft is buffered and checked before SSE delivery.

## Phase 3 — Implemented

- Configurable in-process stand-in model service and standalone OpenAI-compatible simulator API (`simulator.api:app`).
- Variable latency/jitter, slow-tail latency, load-dependent slowdown, random/deterministic failures, timeouts and chunked streaming.
- Simulated RPM, TPM, requests/day, tokens/day and in-flight concurrency limits.
- Separate minute/day/concurrency error codes; daily quota exhaustion is non-retryable.
- Bounded application admission: `MAX_IN_FLIGHT` active calls plus `MAX_QUEUE` waiting capacity.
- Queue-wait and overall provider-operation deadlines.
- Exponential backoff with jitter, bounded retries and `Retry-After` handling.
- Circuit breaker with closed/open/half-open recovery probe.
- Cancellation propagation and capacity release.
- Runtime reliability metrics at `/internal/reliability` after pipeline initialization.
- Deterministic retry-amplification demonstration at `scripts/retry_storm_demo.py`.
- `PROVIDER_MODE=standin` runs without a Groq key.

## Verification

Executed in the build environment using Python 3.13.5, pytest 9.0.2, FastAPI and HTTPX:

- Full cumulative suite: **41 passed, 0 failed, 0 skipped**.
- `python -m compileall -q app simulator scripts tests`: passed.
- `python -m app.cli --help`: passed.
- `python scripts/retry_storm_demo.py`: completed and showed `no_retry_rate_limited=0` versus `with_retry_rate_limited=1` under a deliberately small two-request RPM budget.
- Tests include Phase 1 ingestion/retrieval, Phase 2 pipeline/API, stand-in quota and timeout behavior, standalone simulator JSON/SSE endpoints, retry behavior, daily non-retry, bounded queue, cancellation, deadline, circuit breaker recovery, and a Phase 2+3 stand-in API integration without a Groq key.
- No real Groq API request was made (no user key supplied).

See `tests/TEST_STATUS.md` for the execution record.

## Local requirements / outstanding user actions

1. Extract the ZIP and install dependencies with `pip install -r requirements.txt`.
2. Download the exact papers with `python scripts/download_papers.py`, then run `python -m app.cli ingest`.
3. Real Groq measurement still requires the user's own `GROQ_API_KEY` and controlled local execution.

The earlier build environment could not resolve `arxiv.org`, so the original PDFs are not embedded in the ZIP. The exact version-pinned URLs and downloader are included.

## Approximation boundaries

- The stand-in is a deterministic/configurable load simulator, not an LLM; its generated answer is explicitly labelled simulation-only and must not be used to grade factual answer quality.
- Simulator quotas use process-local fixed windows (60 seconds for minute quotas; configurable daily-window duration from simulator startup), not a replica of the provider's distributed limiter.
- Token estimates use a rough character-based heuristic; they are not Groq tokenizer measurements.
- Application admission, circuit-breaker and quota state are process-local. Multi-worker deployments would need shared coordination.
- Queue scheduling is process-local semaphore scheduling, not strict per-user fairness.
- Citation checks validate source provenance, not full semantic entailment.
- Streaming is buffered until verification; this deliberately trades earlier first-token delivery for check-before-send safety.
- Printed page labels are not reliably parsed; citations use 1-based physical PDF page numbers.

## Next phase

Phase 4: modest controlled real Groq baseline (when credentials and safe budget are available), at least three retrieval configurations, five load scenarios using the stand-in, 15+ question evaluation, `results.csv`, detailed traces and computed tables.
