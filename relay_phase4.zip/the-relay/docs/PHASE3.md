# Phase 3 — Reliability and stand-in model service

## Implemented

- Configurable in-process stand-in provider plus a standalone OpenAI-compatible FastAPI service (`simulator.api:app`).
- Variable base latency and jitter, slow-tail behavior, load-dependent slowdown, deterministic/random failures, deterministic/random timeouts and chunked streaming.
- Simulated RPM, TPM, daily request, daily token and in-flight concurrency limits.
- `Retry-After` metadata and distinct minute/day/concurrency error codes.
- Bounded total admission (`max_in_flight + max_queue`) and provider concurrency semaphore.
- Overall provider-operation deadline including queue wait and retries.
- Exponential backoff with jitter, maximum retry count, and authoritative `Retry-After` handling.
- Circuit breaker with closed/open/half-open states.
- Cancellation propagation and semaphore/queue slot release.
- Provider reliability metrics at `/internal/reliability`.
- Deterministic retry-amplification example in `scripts/retry_storm_demo.py`.

## Important behavior

- Daily request/token exhaustion returns a non-retryable error. Minute-level limits may be retried, but only if `Retry-After` fits within the remaining operation deadline.
- Queue-full and queue-wait timeout failures are not retried by the provider wrapper.
- The wrapper buffers each streaming attempt before yielding it. This prevents duplicate visible text if an upstream stream fails and is retried. The outer API still verifies citations before releasing answer text.
- Client cancellation is propagated so active permits are released.
- The stand-in's deterministic response is labelled simulation-only and must not be used for factual quality grading.

## Test status

See `tests/TEST_STATUS.md` for the most recent execution record.

## Approximation boundaries

The simulator uses in-process state and fixed windows, with a configurable daily-window duration anchored at simulator start. It does not model distributed provider infrastructure, exact provider tokenization, every provider-specific error body, or distributed fairness. The reliability controls are also process-local, so multi-worker deployments would need shared coordination.
