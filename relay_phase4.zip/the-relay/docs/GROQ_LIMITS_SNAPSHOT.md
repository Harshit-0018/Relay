# Groq documentation snapshot for The Relay

**Checked:** 2026-11-12  
**Selected model:** `openai/gpt-oss-20b`  
**Sources:**

- https://console.groq.com/docs/rate-limits
- https://console.groq.com/docs/model/openai/gpt-oss-20b

The public Free Plan rate-limit table currently displays the following row for `openai/gpt-oss-20b`:

| Limit | Publicly displayed value |
|---|---:|
| Requests per minute (RPM) | 30 |
| Requests per day (RPD) | 1,000 |
| Tokens per minute (TPM) | 8,000 |
| Tokens per day (TPD) | 200,000 |

These are **documentation snapshot values**, not a measurement of the user's organization. Groq states that the exact limits can vary and should be checked in the account's Limits page. The account's response headers are the authoritative observations for a live probe.

Groq documents these response headers (among others): `retry-after`, `x-ratelimit-limit-requests`, `x-ratelimit-remaining-requests`, `x-ratelimit-reset-requests`, `x-ratelimit-limit-tokens`, `x-ratelimit-remaining-tokens`, and `x-ratelimit-reset-tokens`. `retry-after` is only set when a 429 rate-limit response is returned. HTTP 429 is the documented rate-limit status.

The current GPT-OSS 20B model page lists a public rate-card price of **$0.075 per million input tokens** and **$0.30 per million output tokens**. The report uses this only to estimate equivalent production cost. A free-tier request has not thereby incurred this amount; actual billed cost and equivalent rate-card cost are separate.

Concurrency / requests-in-flight is not published as a fixed model limit in the cited rate-limit table. Recovery time was not experimentally measured in this project build. A returned reset header or `Retry-After` should be recorded from a real response rather than inferred.

## Evidence status in this build

- Published documentation values: captured above.
- User organization limits: **not measured** (no configured `GROQ_API_KEY`).
- Real 429 behavior and reset timing: **not measured**.
- Real provider latency: **not measured**.
- Real answer quality: **not measured**.

Do not describe the documentation values as account measurements.
