# Phase 4 — Experiments and raw measurements

## Commands

From the `the-relay` project root (Windows PowerShell):

```powershell
python -m experiments.run_load_benchmark
python -m experiments.retrieval_benchmark
python -m experiments.run_real_groq_probe
python -m experiments.build_report_tables
```

The real probe sends no requests unless `GROQ_API_KEY` is configured **and** `--run` is supplied. Its hard cap is five requests:

```powershell
python -m experiments.run_real_groq_probe --run --max-requests 3
```

Paper-backed retrieval comparisons require first downloading and ingesting the exact paper versions:

```powershell
python scripts/download_papers.py
python -m app.cli ingest
python -m experiments.retrieval_benchmark
```

Optional real-model answer evaluation runs up to 15 questions per retrieval setting (45 total at the default setting count), uses sequential requests with conservative 2.2 second pacing, and does not retry provider failures:

```powershell
python -m experiments.retrieval_benchmark --with-groq --max-questions 15
```

This optional run requires the PDFs and `GROQ_API_KEY`. Check the account's current Limits page first. It can consume free-tier quota. Do not run if the quota is nearly exhausted.

## Outputs

- Project-root `results.csv`: exact assignment columns, one row per request. Stand-in answers have blank `answer_grade` because their content is synthetic and must not be graded for factual quality.
- `experiments/results/traces.jsonl`: per-request queue wait, work, retry wait, first-token and post-first-token timings for stand-in load scenarios.
- `experiments/results/scenario_metrics.json`: offered rate, scenario configuration, peak queue length, peak active calls, simulator counters and notes.
- `experiments/results/retrieval_settings.csv`: the three tested retrieval settings and answer-quality fields. Answer quality remains `not measured` until real paper-backed LLM evaluation runs.
- `experiments/results/retrieval_question_results.csv`: paper/page evidence-hit proxy from the known evaluation annotations (only when PDFs are available). This is retrieval evidence recall, not final answer accuracy.
- `experiments/results/real_probe_status.json` and `real_groq_probe_traces.jsonl`: real provider probe status and headers, if run.
- `experiments/results/report_tables.md` and `table_*.csv`: generated assignment tables.

## Method boundaries

The in-process simulator runs with its own process-local fixed-window limits and deterministic random seeds. The stand-in is not an LLM and does not simulate factual answer quality. Token values from the stand-in are estimates. The current build environment had no `.env`, no Groq key and no paper PDFs; any corresponding results are deliberately marked not measured. The real provider probe is opt-in and small by design.

The evidence-hit metric checks whether retrieved chunks overlap the question's expected paper, annotated PDF pages and reference terms. It is a retrieval diagnostic, not a semantic correctness score.
