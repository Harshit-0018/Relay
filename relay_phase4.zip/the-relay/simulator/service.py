from __future__ import annotations

import asyncio
import math
import random
import re
import time
from dataclasses import dataclass
from typing import Any

from app.providers.base import CompletionResult, ProviderError


@dataclass(frozen=True, slots=True)
class SimulatorConfig:
    model: str = "relay-standin-v1"
    base_latency_seconds: float = 0.20
    latency_jitter_seconds: float = 0.05
    slow_tail_probability: float = 0.05
    slow_tail_multiplier: float = 4.0
    failure_probability: float = 0.0
    timeout_probability: float = 0.0
    fail_first_n: int = 0
    timeout_every_n: int = 0
    simulated_timeout_seconds: float = 2.0
    rpm_limit: int = 30
    tpm_limit: int = 18000
    requests_per_day: int = 500
    tokens_per_day: int = 200000
    daily_window_seconds: float = 86400.0
    max_concurrent: int = 8
    overload_threshold: int = 5
    overload_slowdown_factor: float = 1.8
    completion_reservation_tokens: int = 256
    stream_chunk_chars: int = 24
    stream_chunk_interval_seconds: float = 0.01
    random_seed: int = 41

    def __post_init__(self) -> None:
        positive = {
            "slow_tail_multiplier": self.slow_tail_multiplier,
            "simulated_timeout_seconds": self.simulated_timeout_seconds,
            "daily_window_seconds": self.daily_window_seconds,
            "max_concurrent": self.max_concurrent,
            "stream_chunk_chars": self.stream_chunk_chars,
        }
        if any(value <= 0 for value in positive.values()):
            raise ValueError(f"configuration values must be positive: {positive}")
        if self.latency_jitter_seconds < 0 or self.stream_chunk_interval_seconds < 0:
            raise ValueError("jitter and stream interval cannot be negative")
        if not 0 <= self.slow_tail_probability <= 1:
            raise ValueError("slow_tail_probability must be between 0 and 1")
        if not 0 <= self.failure_probability <= 1 or not 0 <= self.timeout_probability <= 1:
            raise ValueError("failure and timeout probabilities must be between 0 and 1")
        if self.overload_slowdown_factor < 1 or self.overload_threshold < 0:
            raise ValueError("overload_slowdown_factor must be at least 1 and threshold non-negative")
        quota_values = (self.rpm_limit, self.tpm_limit, self.requests_per_day, self.tokens_per_day,
                        self.fail_first_n, self.timeout_every_n)
        if any(value < 0 for value in quota_values):
            raise ValueError("quota and deterministic failure values cannot be negative")

    @classmethod
    def from_env(cls) -> "SimulatorConfig":
        import os
        from pathlib import Path

        try:
            from dotenv import load_dotenv
            load_dotenv(Path(__file__).resolve().parents[1] / ".env", override=False)
        except ImportError:
            pass

        def integer(name: str, default: int) -> int:
            return int(os.getenv(name, str(default)))

        def number(name: str, default: float) -> float:
            return float(os.getenv(name, str(default)))

        return cls(
            model=os.getenv("STANDIN_MODEL", "relay-standin-v1"),
            base_latency_seconds=number("STANDIN_BASE_LATENCY_SECONDS", 0.20),
            latency_jitter_seconds=number("STANDIN_LATENCY_JITTER_SECONDS", 0.05),
            slow_tail_probability=number("STANDIN_SLOW_TAIL_PROBABILITY", 0.05),
            slow_tail_multiplier=number("STANDIN_SLOW_TAIL_MULTIPLIER", 4.0),
            failure_probability=number("STANDIN_FAILURE_PROBABILITY", 0.0),
            timeout_probability=number("STANDIN_TIMEOUT_PROBABILITY", 0.0),
            fail_first_n=integer("STANDIN_FAIL_FIRST_N", 0),
            timeout_every_n=integer("STANDIN_TIMEOUT_EVERY_N", 0),
            simulated_timeout_seconds=number("STANDIN_TIMEOUT_SECONDS", 2.0),
            rpm_limit=integer("STANDIN_RPM_LIMIT", 30),
            tpm_limit=integer("STANDIN_TPM_LIMIT", 18000),
            requests_per_day=integer("STANDIN_REQUESTS_PER_DAY", 500),
            tokens_per_day=integer("STANDIN_TOKENS_PER_DAY", 200000),
            daily_window_seconds=number("STANDIN_DAILY_WINDOW_SECONDS", 86400.0),
            max_concurrent=integer("STANDIN_MAX_CONCURRENT", 8),
            overload_threshold=integer("STANDIN_OVERLOAD_THRESHOLD", 5),
            overload_slowdown_factor=number("STANDIN_OVERLOAD_SLOWDOWN_FACTOR", 1.8),
            completion_reservation_tokens=integer("STANDIN_COMPLETION_RESERVATION_TOKENS", 256),
            stream_chunk_chars=integer("STANDIN_STREAM_CHUNK_CHARS", 24),
            stream_chunk_interval_seconds=number("STANDIN_STREAM_CHUNK_INTERVAL_SECONDS", 0.01),
            random_seed=integer("STANDIN_RANDOM_SEED", 41),
        )


class SimulatedModelService:
    """Configurable in-process model service used for safe load/reliability experiments.

    Quotas are fixed-window approximations. They are not intended to reproduce every
    detail of Groq's distributed rate-limit implementation.
    """

    def __init__(self, config: SimulatorConfig | None = None):
        self.config = config or SimulatorConfig.from_env()
        self._lock = asyncio.Lock()
        self._rng = random.Random(self.config.random_seed)
        self._request_number = 0
        now = time.monotonic()
        self._minute_started = now
        self._day_started = now
        self._minute_requests = 0
        self._minute_tokens = 0
        self._day_requests = 0
        self._day_tokens = 0
        self._in_flight = 0
        self._peak_in_flight = 0
        self._stats = {
            "requests": 0, "succeeded": 0, "failed": 0, "rate_limited": 0,
            "timed_out": 0, "cancelled": 0, "tokens_in": 0, "tokens_out": 0,
        }

    @staticmethod
    def estimate_tokens(text: str) -> int:
        return max(1, math.ceil(len(text) / 4)) if text else 0

    @staticmethod
    def _prompt_text(messages: list[dict[str, str]]) -> str:
        return "\n".join(str(item.get("content", "")) for item in messages)

    @staticmethod
    def _simulated_content(messages: list[dict[str, str]]) -> str:
        user_text = next((str(item.get("content", "")) for item in reversed(messages) if item.get("role") == "user"), "")
        match = re.search(r"^\[E\d+\] (\[.*?\])$", user_text, flags=re.MULTILINE)
        if match:
            citation = match.group(1)
            return (
                "STAND-IN SIMULATION: This deterministic response is generated only to exercise "
                "latency, streaming, quota and reliability behavior. It is not a model-generated "
                "factual answer and must not be used to grade answer quality. " + citation
            )
        return (
            "STAND-IN SIMULATION: The local simulator received the request, but no citation-bearing "
            "evidence was present. This is not a factual answer."
        )

    async def _begin(self, messages: list[dict[str, str]], max_completion_tokens: int) -> dict[str, Any]:
        prompt_tokens = self.estimate_tokens(self._prompt_text(messages))
        reserve_tokens = prompt_tokens + min(max_completion_tokens, self.config.completion_reservation_tokens)
        async with self._lock:
            now = time.monotonic()
            if now - self._minute_started >= 60:
                self._minute_started = now
                self._minute_requests = 0
                self._minute_tokens = 0
            if now - self._day_started >= self.config.daily_window_seconds:
                self._day_started = now
                self._day_requests = 0
                self._day_tokens = 0

            if self.config.requests_per_day > 0 and self._day_requests >= self.config.requests_per_day:
                self._stats["rate_limited"] += 1
                raise ProviderError(
                    "Stand-in daily request budget exhausted.", status_code=429,
                    error_code="daily_request_budget_exhausted", retryable=False, limit_scope="day",
                )
            if self.config.tokens_per_day > 0 and self._day_tokens + reserve_tokens > self.config.tokens_per_day:
                self._stats["rate_limited"] += 1
                raise ProviderError(
                    "Stand-in daily token budget exhausted.", status_code=429,
                    error_code="daily_token_budget_exhausted", retryable=False, limit_scope="day",
                )
            if self.config.rpm_limit > 0 and self._minute_requests >= self.config.rpm_limit:
                retry_after = max(0.1, 60.0 - (now - self._minute_started))
                self._stats["rate_limited"] += 1
                raise ProviderError(
                    "Stand-in requests-per-minute limit reached.", status_code=429,
                    retry_after=f"{retry_after:.3f}", error_code="minute_request_rate_limit",
                    retryable=True, limit_scope="minute",
                )
            if self.config.tpm_limit > 0 and self._minute_tokens + reserve_tokens > self.config.tpm_limit:
                retry_after = max(0.1, 60.0 - (now - self._minute_started))
                self._stats["rate_limited"] += 1
                raise ProviderError(
                    "Stand-in tokens-per-minute limit reached.", status_code=429,
                    retry_after=f"{retry_after:.3f}", error_code="minute_token_rate_limit",
                    retryable=True, limit_scope="minute",
                )
            if self._in_flight >= self.config.max_concurrent:
                self._stats["rate_limited"] += 1
                raise ProviderError(
                    "Stand-in concurrency limit reached.", status_code=429, retry_after="0.1",
                    error_code="concurrency_limit", retryable=True, limit_scope="concurrency",
                )

            self._request_number += 1
            request_number = self._request_number
            self._minute_requests += 1
            self._day_requests += 1
            self._minute_tokens += reserve_tokens
            self._day_tokens += reserve_tokens
            self._in_flight += 1
            self._peak_in_flight = max(self._peak_in_flight, self._in_flight)
            self._stats["requests"] += 1

            jitter = self._rng.uniform(0.0, self.config.latency_jitter_seconds)
            latency = self.config.base_latency_seconds + jitter
            if self._rng.random() < self.config.slow_tail_probability:
                latency *= self.config.slow_tail_multiplier
            if self._in_flight > self.config.overload_threshold:
                overload_steps = self._in_flight - self.config.overload_threshold
                latency *= self.config.overload_slowdown_factor ** overload_steps
            fail = request_number <= self.config.fail_first_n or self._rng.random() < self.config.failure_probability
            timeout = (self.config.timeout_every_n > 0 and request_number % self.config.timeout_every_n == 0)
            timeout = timeout or self._rng.random() < self.config.timeout_probability
            return {
                "request_number": request_number,
                "prompt_tokens": prompt_tokens,
                "latency": latency,
                "fail": fail,
                "timeout": timeout,
                "reserved_tokens": reserve_tokens,
                "minute_window_started": self._minute_started,
                "day_window_started": self._day_started,
            }

    async def _release(
        self, *, prompt_tokens: int = 0, output_tokens: int = 0,
        reserved_tokens: int = 0, minute_window_started: float | None = None,
        day_window_started: float | None = None, outcome: str = "succeeded",
    ) -> None:
        async with self._lock:
            self._in_flight = max(0, self._in_flight - 1)
            # Convert the reservation only in the same quota window in which it was made.
            adjustment = prompt_tokens + output_tokens - reserved_tokens
            if minute_window_started == self._minute_started:
                self._minute_tokens = max(0, self._minute_tokens + adjustment)
            if day_window_started == self._day_started:
                self._day_tokens = max(0, self._day_tokens + adjustment)
            self._stats["tokens_in"] += prompt_tokens
            self._stats["tokens_out"] += output_tokens
            if outcome == "succeeded":
                self._stats["succeeded"] += 1
            elif outcome == "timed_out":
                self._stats["timed_out"] += 1
                self._stats["failed"] += 1
            elif outcome == "cancelled":
                self._stats["cancelled"] += 1
            else:
                self._stats["failed"] += 1

    async def _wait_for_model(self, request: dict[str, Any]) -> None:
        exceeds_service_timeout = request["latency"] > self.config.simulated_timeout_seconds
        if request["timeout"] or exceeds_service_timeout:
            await asyncio.sleep(min(request["latency"], self.config.simulated_timeout_seconds))
            raise ProviderError(
                "Stand-in simulated a slow call that exceeded its timeout.", status_code=504,
                error_code="simulated_timeout", retryable=True,
            )
        await asyncio.sleep(request["latency"])
        if request["fail"]:
            raise ProviderError(
                "Stand-in injected a transient model failure.", status_code=503,
                error_code="simulated_transient_failure", retryable=True,
            )

    async def complete(self, messages: list[dict[str, str]], *, max_completion_tokens: int) -> CompletionResult:
        request = await self._begin(messages, max_completion_tokens)
        outcome = "failed"
        output_tokens = 0
        try:
            await self._wait_for_model(request)
            content = self._simulated_content(messages)
            output_tokens = self.estimate_tokens(content)
            outcome = "succeeded"
            return CompletionResult(
                content=content, model=self.config.model,
                input_tokens=request["prompt_tokens"], output_tokens=output_tokens,
                finish_reason="stop",
            )
        except ProviderError as exc:
            if exc.status_code == 504:
                outcome = "timed_out"
            raise
        except asyncio.CancelledError:
            outcome = "cancelled"
            raise
        finally:
            await self._release(
                prompt_tokens=request["prompt_tokens"], output_tokens=output_tokens,
                reserved_tokens=request["reserved_tokens"],
                minute_window_started=request["minute_window_started"],
                day_window_started=request["day_window_started"], outcome=outcome,
            )

    async def stream(self, messages: list[dict[str, str]], *, max_completion_tokens: int):
        request = await self._begin(messages, max_completion_tokens)
        outcome = "failed"
        output_tokens = 0
        try:
            await self._wait_for_model(request)
            content = self._simulated_content(messages)
            output_tokens = self.estimate_tokens(content)
            for offset in range(0, len(content), self.config.stream_chunk_chars):
                if self.config.stream_chunk_interval_seconds:
                    await asyncio.sleep(self.config.stream_chunk_interval_seconds)
                yield content[offset:offset + self.config.stream_chunk_chars]
            outcome = "succeeded"
        except ProviderError as exc:
            if exc.status_code == 504:
                outcome = "timed_out"
            raise
        except asyncio.CancelledError:
            outcome = "cancelled"
            raise
        finally:
            await self._release(
                prompt_tokens=request["prompt_tokens"], output_tokens=output_tokens,
                reserved_tokens=request["reserved_tokens"],
                minute_window_started=request["minute_window_started"],
                day_window_started=request["day_window_started"], outcome=outcome,
            )

    async def metrics(self) -> dict[str, Any]:
        async with self._lock:
            return {
                **self._stats,
                "in_flight": self._in_flight,
                "peak_in_flight": self._peak_in_flight,
                "minute_requests": self._minute_requests,
                "minute_tokens_charged": self._minute_tokens,
                "daily_requests": self._day_requests,
                "daily_tokens_charged": self._day_tokens,
                "limits": {
                    "rpm": self.config.rpm_limit,
                    "tpm": self.config.tpm_limit,
                    "requests_per_day": self.config.requests_per_day,
                    "tokens_per_day": self.config.tokens_per_day,
                    "max_concurrent": self.config.max_concurrent,
                },
            }

