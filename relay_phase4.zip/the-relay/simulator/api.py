from __future__ import annotations

import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

from fastapi import FastAPI
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from app.providers.base import ProviderError
from simulator.service import SimulatedModelService

service = SimulatedModelService()
app = FastAPI(title="The Relay Stand-In Model Service", version="0.3.0")


class Message(BaseModel):
    role: str
    content: str


class CompletionRequest(BaseModel):
    model: str = "relay-standin-v1"
    messages: list[Message] = Field(min_length=1)
    temperature: float = 0.1
    max_tokens: int = 800
    stream: bool = False


@app.get("/health")
async def health() -> dict[str, Any]:
    return {"status": "ok", "service": "relay-standin", "metrics": await service.metrics()}


@app.post("/v1/chat/completions")
async def completions(request: CompletionRequest):
    messages = [item.model_dump() for item in request.messages]
    if request.stream:
        completion_id = "chatcmpl-" + uuid.uuid4().hex[:12]
        async def events() -> AsyncIterator[str]:
            try:
                async for piece in service.stream(messages, max_completion_tokens=request.max_tokens):
                    chunk = {
                        "id": completion_id,
                        "object": "chat.completion.chunk",
                        "model": service.config.model,
                        "choices": [{"index": 0, "delta": {"content": piece}, "finish_reason": None}],
                    }
                    yield "data: " + json.dumps(chunk) + "\n\n"
                yield "data: [DONE]\n\n"
            except ProviderError as exc:
                yield "data: " + json.dumps({"error": {"message": str(exc), "code": exc.error_code}}) + "\n\n"

        return StreamingResponse(events(), media_type="text/event-stream")

    try:
        result = await service.complete(messages, max_completion_tokens=request.max_tokens)
    except ProviderError as exc:
        headers = {"Retry-After": exc.retry_after} if exc.retry_after else None
        return JSONResponse(
            status_code=exc.status_code or 502,
            content={"error": {"message": str(exc), "code": exc.error_code, "limit_scope": exc.limit_scope}},
            headers=headers,
        )
    return {
        "id": "chatcmpl-" + uuid.uuid4().hex[:12],
        "object": "chat.completion",
        "model": result.model,
        "choices": [{"index": 0, "message": {"role": "assistant", "content": result.content}, "finish_reason": result.finish_reason}],
        "usage": {"prompt_tokens": result.input_tokens, "completion_tokens": result.output_tokens,
                  "total_tokens": (result.input_tokens or 0) + (result.output_tokens or 0)},
    }
