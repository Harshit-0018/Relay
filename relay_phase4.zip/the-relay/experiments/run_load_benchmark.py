from __future__ import annotations

import argparse
import asyncio
import json
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.providers.base import ProviderError
from simulator.service import SimulatedModelService, SimulatorConfig
from experiments.common import RESULTS_DIR, append_results, utc_now, write_json, write_csv


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    label: str
    request_count: int
    config: SimulatorConfig
    max_in_flight: int
    max_queue: int
    launch_interval_seconds: float = 0.0
    notes: str = ""


class BenchmarkAdmission:
    """Small FIFO-ish bounded admission gate whose queue metrics are measured locally."""

    def __init__(self, max_in_flight: int, max_queue: int, wait_timeout: float = 5.0):
        self.max_in_flight = max_in_flight
        self.max_queue = max_queue
        self.wait_timeout = wait_timeout
        self.condition = asyncio.Condition()
        self.active = 0
        self.waiting = 0
        self.rejected = 0
        self.peak_queue = 0
        self.peak_active = 0

    async def acquire(self) -> float:
        start = time.perf_counter()
        async with self.condition:
            if self.active < self.max_in_flight:
                self.active += 1
                self.peak_active = max(self.peak_active, self.active)
                return 0.0
            if self.waiting >= self.max_queue:
                self.rejected += 1
                raise ProviderError(
                    "Benchmark admission queue is full.", status_code=503,
                    error_code="benchmark_queue_full", retryable=False,
                )
            self.waiting += 1
            self.peak_queue = max(self.peak_queue, self.waiting)
            try:
                await asyncio.wait_for(
                    self.condition.wait_for(lambda: self.active < self.max_in_flight),
                    timeout=self.wait_timeout,
                )
            except asyncio.TimeoutError as exc:
                self.rejected += 1
                raise ProviderError(
                    "Benchmark admission queue wait timed out.", status_code=504,
                    error_code="benchmark_queue_wait_timeout", retryable=False,
                ) from exc
            finally:
                self.waiting -= 1
            self.active += 1
            self.peak_active = max(self.peak_active, self.active)
        return (time.perf_counter() - start) * 1000

    async def release(self) -> None:
        async with self.condition:
            self.active = max(0, self.active - 1)
            self.condition.notify_all()


@dataclass
class RequestOutcome:
    row: dict[str, Any]
    trace: dict[str, Any]


async def _one_request(
    scenario: Scenario, service: SimulatedModelService, admission: BenchmarkAdmission,
    index: int,
) -> RequestOutcome:
    request_id = f"{scenario.scenario_id}-{index:03d}-{uuid.uuid4().hex[:8]}"
    start_iso = utc_now()
    start = time.perf_counter()
    input_text = f"Benchmark request {request_id}. Explain the role of attention in a research system."
    messages = [
        {"role": "system", "content": "You are a benchmark fixture. Do not provide factual claims."},
        {"role": "user", "content": input_text},
    ]
    tokens_in = service.estimate_tokens("\n".join(item["content"] for item in messages))
    first_token_ms: float | None = None
    tokens_out = 0
    status = "error"
    error_code: str | None = None
    queue_wait_ms = 0.0
    work_ms = 0.0
    retry_wait_ms = 0.0
    response_text = ""
    admitted = False

    try:
        queue_wait_ms = await admission.acquire()
        admitted = True
        work_start = time.perf_counter()
        async for piece in service.stream(messages, max_completion_tokens=128):
            if first_token_ms is None:
                first_token_ms = (time.perf_counter() - start) * 1000
            response_text += piece
        work_ms = (time.perf_counter() - work_start) * 1000
        tokens_out = service.estimate_tokens(response_text)
        status = "ok"
    except ProviderError as exc:
        error_code = exc.error_code or "provider_error"
        if exc.status_code == 429:
            status = "rate_limited"
        elif exc.status_code == 504:
            status = "timeout"
        else:
            status = "error"
        if admitted:
            work_ms = max(0.0, (time.perf_counter() - start) * 1000 - queue_wait_ms)
    except Exception as exc:  # preserve a row for unexpected experiment failures
        error_code = f"unexpected_{type(exc).__name__}"
        status = "error"
        if admitted:
            work_ms = max(0.0, (time.perf_counter() - start) * 1000 - queue_wait_ms)
    finally:
        if admitted:
            await admission.release()

    total_ms = (time.perf_counter() - start) * 1000
    if first_token_ms is not None:
        after_first_token_ms = max(0.0, total_ms - first_token_ms)
    else:
        after_first_token_ms = 0.0
    row = {
        "request_id": request_id,
        "scenario": scenario.scenario_id,
        "source": "stand-in",
        "start_time": start_iso,
        "first_token_ms": round(first_token_ms, 3) if first_token_ms is not None else "",
        "total_ms": round(total_ms, 3),
        "status": status,
        "retries": 0,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "retrieval_setting": "n/a-load-test",
        "answer_grade": "",  # simulator output is deliberately not graded for factual quality
    }
    trace = {
        "request_id": request_id,
        "scenario": scenario.scenario_id,
        "source": "stand-in",
        "start_time": start_iso,
        "queue_wait_ms": round(queue_wait_ms, 3),
        "work_ms": round(work_ms, 3),
        "retry_wait_ms": round(retry_wait_ms, 3),
        "first_token_ms": round(first_token_ms, 3) if first_token_ms is not None else None,
        "after_first_token_ms": round(after_first_token_ms, 3),
        "total_ms": round(total_ms, 3),
        "status": status,
        "error_code": error_code,
        "tokens_in_estimated": tokens_in,
        "tokens_out_estimated": tokens_out,
        "note": "Stand-in response is synthetic and is not suitable for answer-quality grading.",
    }
    return RequestOutcome(row, trace)


def make_scenarios() -> list[Scenario]:
    common = dict(
        base_latency_seconds=0.018,
        latency_jitter_seconds=0.006,
        slow_tail_probability=0.08,
        slow_tail_multiplier=3.0,
        failure_probability=0.0,
        timeout_probability=0.0,
        simulated_timeout_seconds=0.8,
        tpm_limit=100_000,
        requests_per_day=500,
        tokens_per_day=500_000,
        daily_window_seconds=3600.0,
        max_concurrent=40,
        overload_threshold=5,
        overload_slowdown_factor=1.15,
        completion_reservation_tokens=128,
        stream_chunk_chars=48,
        stream_chunk_interval_seconds=0.001,
    )
    return [
        Scenario(
            "steady", "Steady traffic", 20,
            SimulatorConfig(**common, rpm_limit=100, random_seed=101),
            max_in_flight=4, max_queue=24, launch_interval_seconds=0.5,
            notes="20 requests released at a steady 12 ms interval; 4 active slots.",
        ),
        Scenario(
            "burst", "Sudden burst", 24,
            SimulatorConfig(**common, rpm_limit=100, random_seed=102),
            max_in_flight=4, max_queue=32,
            notes="24 requests released together; bounded admission queue absorbs the burst.",
        ),
        Scenario(
            "sustained_overload", "Sustained overload", 40,
            SimulatorConfig(**common, rpm_limit=8, random_seed=103),
            max_in_flight=12, max_queue=40, launch_interval_seconds=0.2,
            notes="40 requests offered at 5 requests/second for roughly eight seconds against an 8 RPM stand-in cap.",
        ),
        Scenario(
            "per_minute_limit_halved", "Per-minute limit halved", 20,
            SimulatorConfig(**common, rpm_limit=5, random_seed=104),
            max_in_flight=10, max_queue=24,
            notes="Configured baseline is 10 RPM; experiment applies half, 5 RPM.",
        ),
        Scenario(
            "daily_budget_exhausted", "Daily budget exhausted", 12,
            SimulatorConfig(**{**common, "requests_per_day": 4}, rpm_limit=100, random_seed=105),
            max_in_flight=8, max_queue=20,
            notes="Daily request budget is deliberately set to four to reach exhaustion safely.",
        ),
    ]


async def run_scenario(scenario: Scenario) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    service = SimulatedModelService(scenario.config)
    admission = BenchmarkAdmission(scenario.max_in_flight, scenario.max_queue)
    started = time.perf_counter()
    outcomes: list[RequestOutcome] = []

    async def launch(index: int) -> RequestOutcome:
        if scenario.launch_interval_seconds:
            await asyncio.sleep(index * scenario.launch_interval_seconds)
        return await _one_request(scenario, service, admission, index + 1)

    outcomes = await asyncio.gather(*(launch(i) for i in range(scenario.request_count)))
    duration = time.perf_counter() - started
    provider_metrics = await service.metrics()
    rows = [item.row for item in outcomes]
    traces = [item.trace for item in outcomes]
    queue_metrics = {
        "peak_queue_length": admission.peak_queue,
        "peak_active_requests": admission.peak_active,
        "queue_rejections": admission.rejected,
        "active_at_end": admission.active,
        "waiting_at_end": admission.waiting,
    }
    metrics = {
        "scenario": scenario.scenario_id,
        "label": scenario.label,
        "source": "stand-in",
        "requests_sent": scenario.request_count,
        "duration_seconds": round(duration, 6),
        "offered_rate_per_minute": round(scenario.request_count / max(duration, 1e-9) * 60, 2),
        "config": asdict(scenario.config),
        "admission": queue_metrics,
        "provider": provider_metrics,
        "notes": scenario.notes,
        "retry_policy": "No retries for load tests; 429 limits are recorded as outcomes. Retry amplification is separately demonstrated in Phase 3.",
    }
    return rows, traces, metrics


async def run_all() -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    all_rows: list[dict[str, Any]] = []
    all_traces: list[dict[str, Any]] = []
    all_metrics: list[dict[str, Any]] = []
    for scenario in make_scenarios():
        rows, traces, metrics = await run_scenario(scenario)
        all_rows.extend(rows)
        all_traces.extend(traces)
        all_metrics.append(metrics)
        counts = {name: sum(1 for row in rows if row["status"] == name) for name in ("ok", "rate_limited", "timeout", "error")}
        print(f"{scenario.scenario_id}: sent={len(rows)} outcomes={counts} duration={metrics['duration_seconds']:.3f}s")
    return all_rows, all_traces, all_metrics


def main() -> int:
    parser = argparse.ArgumentParser(description="Run safe stand-in load scenarios for The Relay")
    parser.add_argument("--append", action="store_true", help="append rows to existing project-root results.csv")
    args = parser.parse_args()
    rows, traces, metrics = asyncio.run(run_all())
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    local_csv = RESULTS_DIR / "standin_load_results.csv"
    columns = list(rows[0].keys()) if rows else []
    write_csv(local_csv, rows, columns)
    write_csv(RESULTS_DIR / "scenario_metrics.csv", metrics, [
        "scenario", "label", "source", "requests_sent", "duration_seconds",
        "offered_rate_per_minute", "notes", "retry_policy",
    ])
    with (RESULTS_DIR / "traces.jsonl").open("w", encoding="utf-8") as handle:
        for trace in traces:
            handle.write(json.dumps(trace, ensure_ascii=False) + "\n")
    write_json(RESULTS_DIR / "scenario_metrics.json", metrics)
    if args.append:
        from experiments.common import append_results
        append_results(rows)
    else:
        # Replace the previous stand-in run but preserve any real Groq observations
        # already appended by the opt-in probe/evaluation scripts.
        from experiments.common import RESULTS_CSV, RESULT_COLUMNS, write_csv as write_project_csv
        prior_real = []
        if RESULTS_CSV.exists():
            import csv
            with RESULTS_CSV.open("r", newline="", encoding="utf-8-sig") as handle:
                prior_real = [item for item in csv.DictReader(handle) if item.get("source") == "real"]
        write_project_csv(RESULTS_CSV, prior_real + rows, RESULT_COLUMNS)
    print(f"Wrote {len(rows)} request rows to {RESULTS_CSV}")
    print(f"Wrote traces and scenario metrics to {RESULTS_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
