from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from experiments.common import (
    RESULTS_CSV, RESULTS_DIR, RESULT_COLUMNS, groq_equivalent_cost_per_1000,
    percentile, read_json, write_csv, write_json,
)


def load_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def numbers(rows: list[dict[str, str]], key: str) -> list[float]:
    output = []
    for row in rows:
        try:
            output.append(float(row[key]))
        except (KeyError, TypeError, ValueError):
            continue
    return output


def pct(numerator: int, denominator: int) -> str:
    return f"{(numerator / denominator * 100):.1f}" if denominator else "not measured"


def build_tables() -> dict[str, Any]:
    rows = load_rows(RESULTS_CSV)
    scenario_metrics = read_json(RESULTS_DIR / "scenario_metrics.json", []) or []
    metrics_by_scenario = {item.get("scenario"): item for item in scenario_metrics}
    retrieval_rows = load_rows(RESULTS_DIR / "retrieval_settings.csv")
    real_rows = [row for row in rows if row.get("source") == "real"]
    real_probe_rows = [row for row in real_rows if row.get("scenario") == "real_baseline"]

    limits_rows = [
        {"limit": "Requests per minute", "value_found": "30 RPM (public Free Plan documentation snapshot for openai/gpt-oss-20b)", "how_found": "Groq rate-limit documentation; exact organization value not queried", "confidence": "medium (published snapshot; account-specific value unverified)"},
        {"limit": "Tokens per minute", "value_found": "8,000 TPM (public Free Plan documentation snapshot)", "how_found": "Groq rate-limit documentation; exact organization value not queried", "confidence": "medium (published snapshot; account-specific value unverified)"},
        {"limit": "Requests per day", "value_found": "1,000 RPD (public Free Plan documentation snapshot)", "how_found": "Groq rate-limit documentation; exact organization value not queried", "confidence": "medium (published snapshot; account-specific value unverified)"},
        {"limit": "Tokens per day", "value_found": "200,000 TPD (public Free Plan documentation snapshot)", "how_found": "Groq rate-limit documentation; exact organization value not queried", "confidence": "medium (published snapshot; account-specific value unverified)"},
        {"limit": "Requests in flight at once", "value_found": "not measured / not listed as a fixed model limit", "how_found": "No live concurrency probe; no fixed value in the cited public model limit table", "confidence": "low"},
        {"limit": "What it returns when a limit is hit", "value_found": "HTTP 429; Retry-After header is set when a 429 limit response is returned", "how_found": "Groq rate-limit documentation; no live 429 observed", "confidence": "high (documented behavior)"},
        {"limit": "Time until it recovers", "value_found": "not measured; inspect Retry-After and reset headers for each actual 429", "how_found": "No real limit was hit; documentation describes reset headers", "confidence": "low"},
    ]
    write_csv(RESULTS_DIR / "table_1_real_service_limits.csv", limits_rows,
              ["limit", "value_found", "how_found", "confidence"])

    latency_rows = []
    outcome_rows = []
    scenario_ids = ["steady", "burst", "sustained_overload", "per_minute_limit_halved", "daily_budget_exhausted"]
    for scenario_id in scenario_ids:
        group = [row for row in rows if row.get("scenario") == scenario_id]
        successful = [row for row in group if row.get("status") == "ok"]
        first = numbers(successful, "first_token_ms")
        total = numbers(successful, "total_ms")
        metric = metrics_by_scenario.get(scenario_id, {})
        duration = metric.get("duration_seconds")
        rate = metric.get("offered_rate_per_minute")
        latency_rows.append({
            "scenario": scenario_id, "source": "stand-in", "requests": len(group),
            "duration_s": f"{duration:.3f}" if isinstance(duration, (int, float)) else "not measured",
            "offered_rate_per_min": f"{rate:.1f}" if isinstance(rate, (int, float)) else "not measured",
            "first_token_p50_ms": f"{percentile(first, 50):.1f}" if first else "not measured",
            "first_token_p95_ms": f"{percentile(first, 95):.1f}" if first else "not measured",
            "first_token_p99_ms": f"{percentile(first, 99):.1f}" if first else "not measured",
            "total_p50_ms": f"{percentile(total, 50):.1f}" if total else "not measured",
            "total_p95_ms": f"{percentile(total, 95):.1f}" if total else "not measured",
            "total_p99_ms": f"{percentile(total, 99):.1f}" if total else "not measured",
            "successful_latency_sample_n": len(successful),
        })
        n = len(group)
        succeeded = sum(row.get("status") == "ok" for row in group)
        limited = sum(row.get("status") == "rate_limited" for row in group)
        failed_or_timeout = sum(row.get("status") in {"timeout", "error"} for row in group)
        retries = numbers(group, "retries")
        token_in = numbers(successful, "tokens_in")
        token_out = numbers(successful, "tokens_out")
        avg_tokens = ((sum(token_in) + sum(token_out)) / len(successful)) if successful else None
        cost = groq_equivalent_cost_per_1000([int(v) for v in token_in], [int(v) for v in token_out])
        outcome_rows.append({
            "scenario": scenario_id,
            "succeeded_pct": pct(succeeded, n),
            "rate_limited_pct": pct(limited, n),
            "timed_out_or_given_up_pct": pct(failed_or_timeout, n),
            "retries_per_request": f"{sum(retries)/len(retries):.2f}" if retries else "not measured",
            "peak_queue_length": metric.get("admission", {}).get("peak_queue_length", "not measured"),
            "tokens_per_answer": f"{avg_tokens:.1f}" if avg_tokens is not None else "not measured",
            "cost_per_1000_answers_usd_equivalent": f"{cost:.6f}" if cost is not None else "not measured",
        })
    # Add an explicit, transparent real baseline row if none exists.
    if not real_probe_rows:
        latency_rows.insert(0, {
            "scenario": "real_groq_baseline", "source": "real (not run)", "requests": 0,
            "duration_s": "not measured", "offered_rate_per_min": "not measured",
            "first_token_p50_ms": "not measured", "first_token_p95_ms": "not measured", "first_token_p99_ms": "not measured",
            "total_p50_ms": "not measured", "total_p95_ms": "not measured", "total_p99_ms": "not measured",
            "successful_latency_sample_n": 0,
        })
        outcome_rows.insert(0, {
            "scenario": "real_groq_baseline", "succeeded_pct": "not measured", "rate_limited_pct": "not measured",
            "timed_out_or_given_up_pct": "not measured", "retries_per_request": "not measured",
            "peak_queue_length": "not measured", "tokens_per_answer": "not measured",
            "cost_per_1000_answers_usd_equivalent": "not measured",
        })
    else:
        real_first = numbers(real_probe_rows, "first_token_ms")
        real_total = numbers([r for r in real_probe_rows if r.get("status") == "ok"], "total_ms")
        latency_rows.insert(0, {
            "scenario": "real_groq_baseline", "source": "real", "requests": len(real_probe_rows),
            "duration_s": "not measured (probe spans recorded in traces)", "offered_rate_per_min": "low-rate probe",
            "first_token_p50_ms": f"{percentile(real_first, 50):.1f}" if real_first else "not measured",
            "first_token_p95_ms": f"{percentile(real_first, 95):.1f}" if real_first else "not measured",
            "first_token_p99_ms": f"{percentile(real_first, 99):.1f}" if real_first else "not measured",
            "total_p50_ms": f"{percentile(real_total, 50):.1f}" if real_total else "not measured",
            "total_p95_ms": f"{percentile(real_total, 95):.1f}" if real_total else "not measured",
            "total_p99_ms": f"{percentile(real_total, 99):.1f}" if real_total else "not measured",
            "successful_latency_sample_n": len(real_total),
        })

    retrieval_table = []
    for setting in retrieval_rows:
        setting_id = setting.get("setting", "")
        answer_rows = [r for r in real_rows if r.get("retrieval_setting") == setting_id and r.get("scenario", "").startswith("retrieval_eval_")]
        grades = [r.get("answer_grade") for r in answer_rows if r.get("answer_grade")]
        successful = [r for r in answer_rows if r.get("status") == "ok"]
        ti, to = numbers(successful, "tokens_in"), numbers(successful, "tokens_out")
        first = numbers(successful, "first_token_ms")
        total = numbers(successful, "total_ms")
        n_questions = len(answer_rows)
        retrieval_table.append({
            "setting_chunk_size_topk_rerank": f"{setting_id}: {setting.get('chunk_size_chars')} chars / top-{setting.get('top_k')} / rerank={setting.get('rerank')}",
            "questions_asked": n_questions,
            "correct_and_cited_pct": pct(sum(g == "correct" for g in grades), len(grades)),
            "wrong_pct": pct(sum(g == "wrong" for g in grades), len(grades)),
            "correctly_refused_pct": pct(sum(g == "refused_correctly" for g in grades), len(grades)),
            "tokens_per_answer": f"{(sum(ti)+sum(to))/len(successful):.1f}" if successful else "not measured",
            "first_token_p50_ms": f"{percentile(first, 50):.1f}" if first else "not measured",
            "first_token_p95_ms": f"{percentile(first, 95):.1f}" if first else "not measured",
            "total_time_p50_ms": f"{percentile(total, 50):.1f}" if total else "not measured",
            "total_time_p95_ms": f"{percentile(total, 95):.1f}" if total else "not measured",
            "retrieval_evidence_hit_pct": setting.get("evidence_hit_pct", "not measured"),
            "answer_quality_status": setting.get("answer_quality_status", "not measured"),
        })
    if not retrieval_table:
        retrieval_table = [{
            "setting_chunk_size_topk_rerank": f"{sid}: {cs} chars / top-{k} / rerank={rr}",
            "questions_asked": 0, "correct_and_cited_pct": "not measured", "wrong_pct": "not measured",
            "correctly_refused_pct": "not measured", "tokens_per_answer": "not measured",
            "first_token_p50_ms": "not measured", "first_token_p95_ms": "not measured",
            "total_time_p50_ms": "not measured", "total_time_p95_ms": "not measured",
            "retrieval_evidence_hit_pct": "not measured", "answer_quality_status": "not measured",
        } for sid, cs, k, rr in [("A",700,3,False), ("B",1200,5,False), ("C",1800,8,True)]]

    # Select the slowest successful stand-in request and decompose its measured timeline.
    trace_path = RESULTS_DIR / "traces.jsonl"
    trace_rows = []
    if trace_path.exists():
        with trace_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    try:
                        trace_rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    successful_traces = [item for item in trace_rows if item.get("status") == "ok" and isinstance(item.get("total_ms"), (int, float))]
    slow_trace = max(successful_traces, key=lambda item: item["total_ms"], default=None)
    if slow_trace:
        queue_wait = float(slow_trace.get("queue_wait_ms") or 0.0)
        retry_wait = float(slow_trace.get("retry_wait_ms") or 0.0)
        first_token = slow_trace.get("first_token_ms")
        total_ms = float(slow_trace.get("total_ms") or 0.0)
        before_first = max(0.0, float(first_token) - queue_wait - retry_wait) if isinstance(first_token, (int, float)) else max(0.0, total_ms - queue_wait - retry_wait)
        after_first = max(0.0, total_ms - float(first_token)) if isinstance(first_token, (int, float)) else 0.0
        slow_analysis = {
            "request_id": slow_trace.get("request_id"), "scenario": slow_trace.get("scenario"),
            "source": slow_trace.get("source"), "total_ms": round(total_ms, 3),
            "waiting_ms": round(queue_wait, 3), "working_before_first_token_ms": round(before_first, 3),
            "working_after_first_token_ms": round(after_first, 3), "retrying_ms": round(retry_wait, 3),
            "first_token_ms": first_token,
            "interpretation": "Measured stand-in request. Queueing and retry waiting occurred before the first token; generation continued after the first token. Retry wait is zero because load-scenario runs deliberately record provider outcomes without retrying rate-limit responses.",
        }
    else:
        slow_analysis = {"status": "not measured", "reason": "No successful request trace is available."}
    write_json(RESULTS_DIR / "slow_request_analysis.json", slow_analysis)

    write_csv(RESULTS_DIR / "table_2a_latency.csv", latency_rows, list(latency_rows[0].keys()))
    write_csv(RESULTS_DIR / "table_2b_outcomes.csv", outcome_rows, list(outcome_rows[0].keys()))
    write_csv(RESULTS_DIR / "table_3_retrieval.csv", retrieval_table, list(retrieval_table[0].keys()))
    write_json(RESULTS_DIR / "table_generation_manifest.json", {
        "results_csv": str(RESULTS_CSV.relative_to(RESULTS_CSV.parent)),
        "rows_in_results_csv": len(rows),
        "standin_rows": sum(r.get("source") == "stand-in" for r in rows),
        "real_rows": len(real_rows),
        "latency_percentile_population": "successful requests only; sample N shown in Table 2a",
        "cost_basis": "equivalent public GPT-OSS 20B price card; not actual cash charged on a free-tier account",
    })

    # Machine-readable overall metrics for later report writing.
    scenario_summaries = []
    for scenario_id in scenario_ids:
        group = [row for row in rows if row.get("scenario") == scenario_id]
        successful = [row for row in group if row.get("status") == "ok"]
        counts = {status: sum(row.get("status") == status for row in group) for status in ("ok", "rate_limited", "timeout", "error")}
        scenario_summaries.append({"scenario": scenario_id, "request_count": len(group), "outcomes": counts,
                                   "success_pct": round(counts["ok"] / len(group) * 100, 1) if group else None,
                                   "rate_limited_pct": round(counts["rate_limited"] / len(group) * 100, 1) if group else None,
                                   "successful_total_p50_ms": percentile(numbers(successful, "total_ms"), 50),
                                   "successful_ttft_p50_ms": percentile(numbers(successful, "first_token_ms"), 50)})
    global_metrics = {
        "generated_at_utc": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        "result_row_count": len(rows), "standin_row_count": sum(r.get("source") == "stand-in" for r in rows),
        "real_row_count": len(real_rows), "real_baseline_row_count": len(real_probe_rows),
        "load_scenarios": scenario_summaries,
        "latency_percentile_population": "successful requests only; p50/p95/p99 computed with linear interpolation",
        "answer_quality": "not measured for stand-in rows; local simulator explicitly disclaims factual answer quality",
    }
    write_json(RESULTS_DIR / "metrics.json", global_metrics)
    write_json(RESULTS_DIR / "experiment_manifest.json", {
        "phase": 4, "raw_file": "results.csv", "raw_schema": RESULT_COLUMNS,
        "load_scenario_count": len(scenario_ids), "retrieval_setting_count": len(retrieval_table),
        "evaluation_question_bank_count": sum(1 for _ in (RESULTS_DIR.parent.parent / "data" / "evaluation_questions" / "questions.jsonl").open(encoding="utf-8") if _.strip()),
        "real_groq_probe_status": read_json(RESULTS_DIR / "real_probe_status.json", {"status": "not run"}),
        "retrieval_evaluation_status": read_json(RESULTS_DIR / "retrieval_eval_status.json", {"status": "not run"}),
        "source_classification": "real rows are emitted only by opt-in real Groq scripts; stand-in rows are simulated",
    })

    md = ["# Generated assignment tables", "", "Generated from project-root `results.csv` plus experiment metadata.", "",
          "**Percentile rule:** successful requests only; sample size is included in Table 2a.",
          "**Cost rule:** equivalent public GPT-OSS 20B rate-card estimate, not a cash charge to the free-tier account.", "",
          "## Table 1 — Limits found in the real service", "",
          "| Limit | Value found | How found | Confidence |", "|---|---|---|---|"]
    for r in limits_rows:
        md.append(f"| {r['limit']} | {r['value_found']} | {r['how_found']} | {r['confidence']} |")
    md += ["", "## Table 2a — Latency", "", "| Scenario | Source | Requests | Duration (s) | Offered/min | TTFT p50/p95/p99 (ms) | Total p50/p95/p99 (ms) | Success sample N |", "|---|---|---:|---:|---:|---|---|---:|"]
    for r in latency_rows:
        md.append(f"| {r['scenario']} | {r['source']} | {r['requests']} | {r['duration_s']} | {r['offered_rate_per_min']} | {r['first_token_p50_ms']} / {r['first_token_p95_ms']} / {r['first_token_p99_ms']} | {r['total_p50_ms']} / {r['total_p95_ms']} / {r['total_p99_ms']} | {r['successful_latency_sample_n']} |")
    md += ["", "## Table 2b — Outcomes", "", "| Scenario | Success % | Rate-limited % | Timed out/given up % | Retries/request | Peak queue | Tokens/answer | Cost/1,000 equivalent USD |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in outcome_rows:
        md.append(f"| {r['scenario']} | {r['succeeded_pct']} | {r['rate_limited_pct']} | {r['timed_out_or_given_up_pct']} | {r['retries_per_request']} | {r['peak_queue_length']} | {r['tokens_per_answer']} | {r['cost_per_1000_answers_usd_equivalent']} |")
    md += ["", "## Table 3 — Retrieval settings", "", "| Setting | Questions | Correct & cited % | Wrong % | Correct refusal % | Tokens/answer | TTFT p50/p95 | Total p50/p95 | Evidence hit % |", "|---|---:|---:|---:|---:|---:|---|---|---:|"]
    for r in retrieval_table:
        md.append(f"| {r['setting_chunk_size_topk_rerank']} | {r['questions_asked']} | {r['correct_and_cited_pct']} | {r['wrong_pct']} | {r['correctly_refused_pct']} | {r['tokens_per_answer']} | {r['first_token_p50_ms']} / {r['first_token_p95_ms']} | {r['total_time_p50_ms']} / {r['total_time_p95_ms']} | {r['retrieval_evidence_hit_pct']} |")
    md += ["", "## Slow request latency breakdown", ""]
    if slow_trace:
        md += [
            f"- Request: `{slow_analysis['request_id']}` ({slow_analysis['scenario']}, {slow_analysis['source']})",
            f"- Total: {slow_analysis['total_ms']:.1f} ms",
            f"- Waiting: {slow_analysis['waiting_ms']:.1f} ms",
            f"- Working before first token: {slow_analysis['working_before_first_token_ms']:.1f} ms",
            f"- Working after first token: {slow_analysis['working_after_first_token_ms']:.1f} ms",
            f"- Retrying: {slow_analysis['retrying_ms']:.1f} ms",
            "", slow_analysis["interpretation"],
        ]
    else:
        md.append("not measured")
    md += ["", "## Interpretation boundaries", "", "Stand-in outputs are synthetic and were not assigned factual answer grades. Real Groq and paper-backed answer quality remain `not measured` unless corresponding rows are present in `results.csv`.", ""]
    (RESULTS_DIR / "report_tables.md").write_text("\n".join(md), encoding="utf-8")
    return {"rows": len(rows), "scenarios": len(scenario_ids), "real_rows": len(real_rows), "retrieval_settings": len(retrieval_table)}


def main() -> int:
    result = build_tables()
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
