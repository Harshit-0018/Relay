# Generated assignment tables

Generated from project-root `results.csv` plus experiment metadata.

**Percentile rule:** successful requests only; sample size is included in Table 2a.
**Cost rule:** equivalent public GPT-OSS 20B rate-card estimate, not a cash charge to the free-tier account.

## Table 1 — Limits found in the real service

| Limit | Value found | How found | Confidence |
|---|---|---|---|
| Requests per minute | 30 RPM (public Free Plan documentation snapshot for openai/gpt-oss-20b) | Groq rate-limit documentation; exact organization value not queried | medium (published snapshot; account-specific value unverified) |
| Tokens per minute | 8,000 TPM (public Free Plan documentation snapshot) | Groq rate-limit documentation; exact organization value not queried | medium (published snapshot; account-specific value unverified) |
| Requests per day | 1,000 RPD (public Free Plan documentation snapshot) | Groq rate-limit documentation; exact organization value not queried | medium (published snapshot; account-specific value unverified) |
| Tokens per day | 200,000 TPD (public Free Plan documentation snapshot) | Groq rate-limit documentation; exact organization value not queried | medium (published snapshot; account-specific value unverified) |
| Requests in flight at once | not measured / not listed as a fixed model limit | No live concurrency probe; no fixed value in the cited public model limit table | low |
| What it returns when a limit is hit | HTTP 429; Retry-After header is set when a 429 limit response is returned | Groq rate-limit documentation; no live 429 observed | high (documented behavior) |
| Time until it recovers | not measured; inspect Retry-After and reset headers for each actual 429 | No real limit was hit; documentation describes reset headers | low |

## Table 2a — Latency

| Scenario | Source | Requests | Duration (s) | Offered/min | TTFT p50/p95/p99 (ms) | Total p50/p95/p99 (ms) | Success sample N |
|---|---|---:|---:|---:|---|---|---:|
| real_groq_baseline | real (not run) | 0 | not measured | not measured | not measured / not measured / not measured | not measured / not measured / not measured | 0 |
| steady | stand-in | 20 | 9.530 | 125.9 | 22.9 / 27.1 / 53.1 | 25.1 / 29.4 / 55.3 | 20 |
| burst | stand-in | 24 | 0.155 | 9307.1 | 84.6 / 151.4 / 151.9 | 86.9 / 153.6 / 154.1 | 24 |
| sustained_overload | stand-in | 40 | 7.801 | 307.6 | 21.9 / 47.5 / 57.0 | 24.2 / 49.7 / 59.2 | 8 |
| per_minute_limit_halved | stand-in | 20 | 0.028 | 43198.0 | 21.9 / 24.7 / 25.2 | 24.2 / 27.0 / 27.5 | 5 |
| daily_budget_exhausted | stand-in | 12 | 0.028 | 25839.4 | 21.9 / 24.9 / 25.3 | 24.2 / 27.2 / 27.6 | 4 |

## Table 2b — Outcomes

| Scenario | Success % | Rate-limited % | Timed out/given up % | Retries/request | Peak queue | Tokens/answer | Cost/1,000 equivalent USD |
|---|---:|---:|---:|---:|---:|---:|---:|
| real_groq_baseline | not measured | not measured | not measured | not measured | not measured | not measured | not measured |
| steady | 100.0 | 0.0 | 0.0 | 0.00 | 0 | 73.0 | 0.013350 |
| burst | 100.0 | 0.0 | 0.0 | 0.00 | 20 | 73.0 | 0.013350 |
| sustained_overload | 20.0 | 80.0 | 0.0 | 0.00 | 0 | 76.0 | 0.013575 |
| per_minute_limit_halved | 25.0 | 75.0 | 0.0 | 0.00 | 0 | 77.0 | 0.013650 |
| daily_budget_exhausted | 33.3 | 66.7 | 0.0 | 0.00 | 0 | 77.0 | 0.013650 |

## Table 3 — Retrieval settings

| Setting | Questions | Correct & cited % | Wrong % | Correct refusal % | Tokens/answer | TTFT p50/p95 | Total p50/p95 | Evidence hit % |
|---|---:|---:|---:|---:|---:|---|---|---:|
| A: 700 chars / top-3 / rerank=False | 0 | not measured | not measured | not measured | not measured | not measured / not measured | not measured / not measured | not measured |
| B: 1200 chars / top-5 / rerank=False | 0 | not measured | not measured | not measured | not measured | not measured / not measured | not measured / not measured | not measured |
| C: 1800 chars / top-8 / rerank=True | 0 | not measured | not measured | not measured | not measured | not measured / not measured | not measured / not measured | not measured |

## Slow request latency breakdown

- Request: `burst-023-e62cf1ba` (burst, stand-in)
- Total: 154.1 ms
- Waiting: 127.6 ms
- Working before first token: 24.3 ms
- Working after first token: 2.2 ms
- Retrying: 0.0 ms

Measured stand-in request. Queueing and retry waiting occurred before the first token; generation continued after the first token. Retry wait is zero because load-scenario runs deliberately record provider outcomes without retrying rate-limit responses.

## Interpretation boundaries

Stand-in outputs are synthetic and were not assigned factual answer grades. Real Groq and paper-backed answer quality remain `not measured` unless corresponding rows are present in `results.csv`.
