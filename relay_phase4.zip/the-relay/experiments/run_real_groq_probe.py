from __future__ import annotations

import argparse
import asyncio
import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx

from app.config import Settings
from experiments.common import RESULTS_DIR, append_results, write_json

RATE_HEADERS = [
    "retry-after",
    "x-ratelimit-limit-requests", "x-ratelimit-remaining-requests", "x-ratelimit-reset-requests",
    "x-ratelimit-limit-tokens", "x-ratelimit-remaining-tokens", "x-ratelimit-reset-tokens",
    "x-ratelimit-limit-requests-day", "x-ratelimit-remaining-requests-day", "x-ratelimit-reset-requests-day",
    "x-ratelimit-limit-tokens-day", "x-ratelimit-remaining-tokens-day", "x-ratelimit-reset-tokens-day",
]


def estimate_tokens(text: str) -> int:
    return max(1, (len(text) + 3) // 4) if text else 0


async def probe_once(settings: Settings, index: int) -> tuple[dict[str, Any], dict[str, Any]]:
    request_id = f"groq-probe-{index:02d}-{uuid.uuid4().hex[:8]}"
    start_iso = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    start = time.perf_counter()
    prompt = "Reply with exactly: OK"
    payload = {
        "model": settings.groq_model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_completion_tokens": 8,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    first_token_ms = None
    output_text = ""
    tokens_in = estimate_tokens(prompt)
    tokens_out = ""
    headers_seen: dict[str, str] = {}
    status = "error"
    error_text = None
    http_status = None
    try:
        timeout = httpx.Timeout(settings.request_timeout_seconds)
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream(
                "POST", f"{settings.groq_base_url}/chat/completions",
                headers={"Authorization": f"Bearer {settings.groq_api_key}", "Content-Type": "application/json"},
                json=payload,
            ) as response:
                http_status = response.status_code
                headers_seen = {key: response.headers[key] for key in RATE_HEADERS if key in response.headers}
                if not response.is_success:
                    body = (await response.aread()).decode("utf-8", errors="replace")
                    error_text = body[:500]
                    status = "rate_limited" if response.status_code == 429 else "timeout" if response.status_code == 504 else "error"
                else:
                    async for line in response.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        try:
                            event = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        usage = event.get("usage") or {}
                        if usage:
                            tokens_in = usage.get("prompt_tokens", tokens_in)
                            tokens_out = usage.get("completion_tokens", tokens_out)
                        choices = event.get("choices") or []
                        if choices:
                            piece = choices[0].get("delta", {}).get("content")
                            if isinstance(piece, str) and piece:
                                if first_token_ms is None:
                                    first_token_ms = (time.perf_counter() - start) * 1000
                                output_text += piece
                    status = "ok"
    except httpx.TimeoutException as exc:
        status, error_text = "timeout", str(exc)
    except httpx.HTTPError as exc:
        status, error_text = "error", f"{type(exc).__name__}: {exc}"
    total_ms = (time.perf_counter() - start) * 1000
    row = {
        "request_id": request_id, "scenario": "real_baseline", "source": "real",
        "start_time": start_iso,
        "first_token_ms": round(first_token_ms, 3) if first_token_ms is not None else "",
        "total_ms": round(total_ms, 3), "status": status, "retries": 0,
        "tokens_in": tokens_in if isinstance(tokens_in, int) else "",
        "tokens_out": tokens_out if isinstance(tokens_out, int) else estimate_tokens(output_text) if output_text else 0,
        "retrieval_setting": "n/a-real-probe", "answer_grade": "",
    }
    trace = {
        "request_id": request_id, "source": "real", "model": settings.groq_model,
        "start_time": start_iso, "http_status": http_status, "status": status,
        "first_token_ms": row["first_token_ms"], "total_ms": round(total_ms, 3),
        "rate_limit_headers": headers_seen, "error": error_text,
        "note": "Small controlled provider probe; no quota was deliberately exhausted.",
    }
    return row, trace


async def run_probe(settings: Settings, count: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rows, traces = [], []
    for index in range(1, count + 1):
        row, trace = await probe_once(settings, index)
        rows.append(row)
        traces.append(trace)
        print(f"probe {index}/{count}: status={row['status']} total_ms={row['total_ms']}")
        if row["status"] != "ok":
            print("Stopping the real probe after the first non-success to avoid repeated quota/auth failures.")
            break
        if index < count:
            await asyncio.sleep(2.2)  # conservative request pacing under free-tier limits
    return rows, traces


def main() -> int:
    parser = argparse.ArgumentParser(description="Optional modest real Groq baseline probe")
    parser.add_argument("--run", action="store_true", help="explicitly authorize up to the configured number of real requests")
    parser.add_argument("--max-requests", type=int, default=3, choices=range(1, 6), help="hard cap: 1..5 requests")
    args = parser.parse_args()
    settings = Settings.from_env()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    if not settings.groq_api_key:
        state = {"status": "not_measured", "reason": "GROQ_API_KEY is not configured; no real API request was attempted.", "requests_attempted": 0}
        write_json(RESULTS_DIR / "real_probe_status.json", state)
        print(state["reason"])
        return 0
    if not args.run:
        state = {"status": "ready_not_run", "reason": "Key detected but no request sent. Re-run with --run to authorize the small probe.", "requests_attempted": 0}
        write_json(RESULTS_DIR / "real_probe_status.json", state)
        print(state["reason"])
        return 0
    rows, traces = asyncio.run(run_probe(settings, args.max_requests))
    append_results(rows)
    trace_path = RESULTS_DIR / "real_groq_probe_traces.jsonl"
    with trace_path.open("w", encoding="utf-8") as handle:
        for trace in traces:
            handle.write(json.dumps(trace, ensure_ascii=False) + "\n")
    state = {
        "status": "measured", "model": settings.groq_model,
        "requests_attempted": len(rows),
        "successful": sum(row["status"] == "ok" for row in rows),
        "rate_limited": sum(row["status"] == "rate_limited" for row in rows),
        "timeouts": sum(row["status"] == "timeout" for row in rows),
        "errors": sum(row["status"] == "error" for row in rows),
        "hard_cap": 5,
        "note": "Observed values apply only to this account, model, time and probe. Never infer daily exhaustion from this probe.",
    }
    write_json(RESULTS_DIR / "real_probe_status.json", state)
    print(json.dumps(state, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
