from __future__ import annotations

import argparse
import asyncio
import csv
import json
import math
import os
import re
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from app.config import Settings
from app.providers.groq_provider import GroqProvider
from app.reliability.config import ReliabilityConfig
from app.reliability.resilient_provider import ResilientProvider
from app.retrieval.chunking import build_chunks
from app.retrieval.ingest import extract_pdf_pages, load_registry
from app.retrieval.schemas import Chunk
from app.retrieval.store import save_chunks
from app.retrieval.tool import PaperSearchTool
from app.services.pipeline import PaperQAPipeline
from experiments.common import ROOT, RESULTS_DIR, read_json, write_json, write_csv, append_results


@dataclass(frozen=True)
class RetrievalSetting:
    setting_id: str
    label: str
    chunk_size: int
    overlap: int
    top_k: int
    rerank: bool


SETTINGS = [
    RetrievalSetting("A", "small chunks / low context", 700, 80, 3, False),
    RetrievalSetting("B", "balanced baseline", 1200, 180, 5, False),
    RetrievalSetting("C", "large chunks / lexical rerank", 1800, 260, 8, True),
]
QUESTIONS_PATH = ROOT / "data" / "evaluation_questions" / "questions.jsonl"
PAPERS_DIR = ROOT / "data" / "papers"
PROCESSED_DIR = ROOT / "data" / "processed"


def load_questions() -> list[dict[str, Any]]:
    return [json.loads(line) for line in QUESTIONS_PATH.read_text(encoding="utf-8").splitlines() if line.strip()]


def build_setting_chunks(setting: RetrievalSetting) -> list[Chunk]:
    registry = load_registry(PAPERS_DIR / "paper_registry.json")
    pages = []
    missing = []
    for paper in registry:
        path = PAPERS_DIR / paper.pdf_filename
        if not path.exists():
            missing.append(paper.pdf_filename)
            continue
        pages.extend(extract_pdf_pages(path, paper))
    if missing:
        raise FileNotFoundError("Missing exact-version PDFs: " + ", ".join(missing))
    chunks: list[Chunk] = []
    for page in pages:
        chunks.extend(build_chunks([page], chunk_size=setting.chunk_size, overlap=setting.overlap))
    return chunks


def lexical_rerank(query: str, candidates: list[tuple[Chunk, float]]) -> list[tuple[Chunk, float]]:
    terms = {word.lower() for word in re.findall(r"[A-Za-z0-9][A-Za-z0-9._-]+", query) if len(word) > 2}
    if not terms:
        return candidates
    def key(pair: tuple[Chunk, float]) -> tuple[float, float]:
        chunk, bm25_score = pair
        text_terms = {word.lower() for word in re.findall(r"[A-Za-z0-9][A-Za-z0-9._-]+", chunk.text) if len(word) > 2}
        overlap_ratio = len(terms & text_terms) / len(terms)
        return (overlap_ratio, bm25_score)
    return sorted(candidates, key=key, reverse=True)


def retrieval_evidence_metrics(questions: list[dict[str, Any]], chunks: list[Chunk], setting: RetrievalSetting) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    from app.retrieval.bm25 import BM25Retriever
    retriever = BM25Retriever(chunks)
    per_question = []
    latencies = []
    evidence_hits = 0
    for question in questions:
        started = time.perf_counter()
        candidates = retriever.search(question["question"], top_k=setting.top_k * (2 if setting.rerank else 1))
        pairs = [(item.chunk, item.score) for item in candidates]
        if setting.rerank:
            pairs = lexical_rerank(question["question"], pairs)
        selected = pairs[:setting.top_k]
        elapsed = (time.perf_counter() - started) * 1000
        latencies.append(elapsed)
        expected_papers = set(question.get("expected_papers", []))
        expected_pages = set(question.get("evidence_pdf_pages", []))
        expected_terms = [str(term).lower() for term in question.get("expected_terms", [])]
        combined = " ".join(chunk.text.lower() for chunk, _ in selected)
        source_page_hit = any(
            (f"{chunk.arxiv_id}v{chunk.version}" in expected_papers or f"{chunk.arxiv_id}v{chunk.version}" in expected_papers)
            and (not expected_pages or chunk.pdf_page in expected_pages)
            for chunk, _ in selected
        )
        term_hits = sum(1 for term in expected_terms if term in combined)
        term_threshold = max(1, math.ceil(len(expected_terms) * 0.5)) if expected_terms else 0
        evidence_hit = bool(question.get("answerable")) and source_page_hit and term_hits >= term_threshold
        evidence_hits += int(evidence_hit)
        per_question.append({
            "question_id": question["question_id"],
            "setting": setting.setting_id,
            "answerable": question.get("answerable", False),
            "retrieved_count": len(selected),
            "source_page_hit": source_page_hit,
            "expected_term_hits": term_hits,
            "expected_term_count": len(expected_terms),
            "evidence_hit": evidence_hit,
            "retrieval_ms": round(elapsed, 3),
            "retrieved_chunk_ids": ";".join(chunk.chunk_id for chunk, _ in selected),
        })
    return ({
        "setting": setting.setting_id,
        "label": setting.label,
        "chunk_size_chars": setting.chunk_size,
        "overlap_chars": setting.overlap,
        "top_k": setting.top_k,
        "rerank": setting.rerank,
        "questions_evaluated_for_retrieval": len(questions),
        "evidence_hit_pct": round(evidence_hits / max(1, sum(bool(q.get("answerable")) for q in questions)) * 100, 1),
        "retrieval_p50_ms": round(_percentile(latencies, 50), 3),
        "retrieval_p95_ms": round(_percentile(latencies, 95), 3),
        "answer_quality_status": "not measured: no live LLM generation executed",
    }, per_question)


def _percentile(values: list[float], p: float) -> float:
    from experiments.common import percentile
    return percentile(values, p) or 0.0


class TimedGroqProvider(GroqProvider):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.measure_started = 0.0
        self.first_token_ms: float | None = None

    async def stream(self, messages, *, temperature, max_completion_tokens):
        self.first_token_ms = None
        async for piece in super().stream(messages, temperature=temperature, max_completion_tokens=max_completion_tokens):
            if self.first_token_ms is None:
                self.first_token_ms = (time.perf_counter() - self.measure_started) * 1000
            yield piece


def grade_answer(question: dict[str, Any], answer: Any, citations: list[str], refused: bool) -> str:
    if not question.get("answerable", False):
        return "refused_correctly" if refused else "refused_wrongly"
    if refused:
        return "refused_wrongly"
    expected_papers = question.get("expected_papers", [])
    expected_pages = question.get("evidence_pdf_pages", [])
    citation_match = any(
        any(f"arxiv:{paper}" in citation.lower() for paper in expected_papers)
        and (not expected_pages or any(f"pdf p. {page}" in citation.lower() for page in expected_pages))
        for citation in citations
    )
    answer_text = str(answer).lower()
    expected_terms = [str(term).lower() for term in question.get("expected_terms", [])]
    term_hits = sum(1 for term in expected_terms if term in answer_text)
    threshold = max(1, math.ceil(len(expected_terms) * 0.5)) if expected_terms else 1
    return "correct" if citation_match and term_hits >= threshold else "wrong"


async def _run_llm_eval(setting: RetrievalSetting, questions: list[dict[str, Any]], chunks_path: Path, limit: int) -> list[dict[str, Any]]:
    base = Settings.from_env()
    if not base.groq_api_key:
        raise RuntimeError("GROQ_API_KEY is not configured")
    provider = TimedGroqProvider(
        api_key=base.groq_api_key, model=base.groq_model,
        base_url=base.groq_base_url, timeout_seconds=base.request_timeout_seconds,
    )
    resilient = ResilientProvider(provider, ReliabilityConfig(
        max_in_flight=1, max_queue=2, queue_wait_seconds=20,
        provider_deadline_seconds=60, max_retries=0,
    ))
    settings = replace(base, chunks_path=chunks_path, default_top_k=setting.top_k,
                       max_top_k=max(setting.top_k, 8), max_correction_attempts=0,
                       max_completion_tokens=500)
    pipeline = PaperQAPipeline(PaperSearchTool(chunks_path), resilient, settings)
    rows = []
    for index, question in enumerate(questions[:limit]):
        provider.measure_started = time.perf_counter()
        started = provider.measure_started
        try:
            result = await pipeline.answer(question["question"], top_k=setting.top_k, use_upstream_stream=True)
            grade = grade_answer(question, result.answer, result.citations, result.refused)
            rows.append({
                "request_id": f"rag-{setting.setting_id}-{question['question_id']}",
                "scenario": f"retrieval_eval_{setting.setting_id}",
                "source": "real",
                "start_time": "",  # filled by shared results appender's timestamp-independent schema
                "first_token_ms": round(provider.first_token_ms, 3) if provider.first_token_ms is not None else "",
                "total_ms": round(result.total_ms, 3),
                "status": "ok",
                "retries": 0,
                "tokens_in": result.input_tokens if result.input_tokens is not None else "",
                "tokens_out": result.output_tokens if result.output_tokens is not None else "",
                "retrieval_setting": setting.setting_id,
                "answer_grade": grade,
            })
            rows[-1]["start_time"] = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        except Exception as exc:
            from app.providers.base import ProviderError
            status = "rate_limited" if isinstance(exc, ProviderError) and exc.status_code == 429 else "timeout" if isinstance(exc, ProviderError) and exc.status_code == 504 else "error"
            rows.append({
                "request_id": f"rag-{setting.setting_id}-{question['question_id']}",
                "scenario": f"retrieval_eval_{setting.setting_id}", "source": "real",
                "start_time": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
                "first_token_ms": round(provider.first_token_ms, 3) if provider.first_token_ms is not None else "",
                "total_ms": round((time.perf_counter() - started) * 1000, 3),
                "status": status, "retries": 0, "tokens_in": "", "tokens_out": "",
                "retrieval_setting": setting.setting_id, "answer_grade": "",
            })
            # Stop after an error (especially HTTP 429/401) rather than continuing to
            # consume a depleted quota or repeatedly probe bad credentials.
            break
        # Conservative pacing under free-tier limits; this is a deliberate evaluation run.
        await asyncio.sleep(2.2)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate three retrieval configurations; optional real Groq QA")
    parser.add_argument("--with-groq", action="store_true", help="run real model answers; requires GROQ_API_KEY")
    parser.add_argument("--max-questions", type=int, default=15, help="maximum QA questions per retrieval setting")
    args = parser.parse_args()
    questions = load_questions()
    write_json(RESULTS_DIR / "evaluation_dataset_summary.json", {
        "question_count": len(questions),
        "answerable_count": sum(bool(item.get("answerable")) for item in questions),
        "unanswerable_count": sum(not bool(item.get("answerable")) for item in questions),
        "question_ids": [item.get("question_id") for item in questions],
        "grading_fields": ["expected_papers", "expected_terms", "evidence_pdf_pages", "reference_answer"],
    })
    all_evidence_rows = []
    setting_rows = []
    groq_rows = []
    missing = []
    for setting in SETTINGS:
        chunks_path = PROCESSED_DIR / f"chunks_setting_{setting.setting_id}.jsonl"
        try:
            chunks = build_setting_chunks(setting)
            save_chunks(chunks_path, chunks)
            summary, question_rows = retrieval_evidence_metrics(questions, chunks, setting)
            summary["chunk_count"] = len(chunks)
            summary["status"] = "measured_retrieval_only"
            all_evidence_rows.extend(question_rows)
        except Exception as exc:
            missing.append({"setting": setting.setting_id, "reason": str(exc)})
            summary = {
                "setting": setting.setting_id, "label": setting.label,
                "chunk_size_chars": setting.chunk_size, "overlap_chars": setting.overlap,
                "top_k": setting.top_k, "rerank": setting.rerank,
                "questions_evaluated_for_retrieval": 0, "evidence_hit_pct": "not measured",
                "retrieval_p50_ms": "not measured", "retrieval_p95_ms": "not measured",
                "answer_quality_status": "not measured: source PDFs unavailable",
                "chunk_count": 0, "status": "not_measured",
            }
        if args.with_groq and summary.get("status") == "measured_retrieval_only":
            try:
                rows = asyncio.run(_run_llm_eval(setting, questions, chunks_path, args.max_questions))
                groq_rows.extend(rows)
                grades = [row["answer_grade"] for row in rows if row.get("answer_grade")]
                summary["questions_asked_to_model"] = len(rows)
                summary["correct_and_cited_pct"] = round(sum(g == "correct" for g in grades) / max(1, len(grades)) * 100, 1)
                summary["wrong_pct"] = round(sum(g == "wrong" for g in grades) / max(1, len(grades)) * 100, 1)
                summary["correctly_refused_pct"] = round(sum(g == "refused_correctly" for g in grades) / max(1, len(grades)) * 100, 1)
                summary["wrongly_refused_pct"] = round(sum(g == "refused_wrongly" for g in grades) / max(1, len(grades)) * 100, 1)
                summary["answer_quality_status"] = "measured with transparent expected-term + citation rubric"
            except Exception as exc:
                summary["answer_quality_status"] = f"not measured: {type(exc).__name__}: {exc}"
        else:
            summary["questions_asked_to_model"] = 0
            summary["correct_and_cited_pct"] = "not measured"
            summary["wrong_pct"] = "not measured"
            summary["correctly_refused_pct"] = "not measured"
            summary["wrongly_refused_pct"] = "not measured"
        setting_rows.append(summary)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(RESULTS_DIR / "retrieval_settings.csv", setting_rows, list(dict.fromkeys(k for row in setting_rows for k in row)))
    write_csv(RESULTS_DIR / "retrieval_question_results.csv", all_evidence_rows,
              ["question_id", "setting", "answerable", "retrieved_count", "source_page_hit", "expected_term_hits", "expected_term_count", "evidence_hit", "retrieval_ms", "retrieved_chunk_ids"])
    write_json(RESULTS_DIR / "retrieval_eval_status.json", {
        "pdfs_available": not missing,
        "missing_or_failed_settings": missing,
        "question_bank_size": len(questions),
        "groq_requested": args.with_groq,
        "groq_answer_rows_created": len(groq_rows),
        "grading_note": "A heuristic expected-term plus exact paper/page citation rubric; inspect grades manually before submission.",
    })
    if groq_rows:
        append_results(groq_rows)
    print(f"Retrieval settings recorded: {len(setting_rows)}; paper-backed questions measured: {len(all_evidence_rows)}")
    print(f"Live model rows: {len(groq_rows)}; source PDFs missing/failed: {len(missing)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
