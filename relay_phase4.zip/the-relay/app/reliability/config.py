from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ReliabilityConfig:
    max_in_flight: int = 8
    max_queue: int = 32
    queue_wait_seconds: float = 10.0
    provider_deadline_seconds: float = 50.0
    max_retries: int = 2
    retry_base_seconds: float = 0.25
    retry_max_seconds: float = 2.0
    retry_jitter: float = 0.20
    circuit_failure_threshold: int = 5
    circuit_recovery_seconds: float = 10.0
    random_seed: int = 41

    def __post_init__(self) -> None:
        if self.max_in_flight < 1:
            raise ValueError("max_in_flight must be at least 1")
        if self.max_queue < 0:
            raise ValueError("max_queue cannot be negative")
        if self.queue_wait_seconds <= 0 or self.provider_deadline_seconds <= 0:
            raise ValueError("queue and provider deadlines must be positive")
        if self.max_retries < 0:
            raise ValueError("max_retries cannot be negative")
        if self.retry_base_seconds < 0 or self.retry_max_seconds < self.retry_base_seconds or self.retry_jitter < 0:
            raise ValueError("invalid retry delay settings")
        if self.circuit_failure_threshold < 1 or self.circuit_recovery_seconds <= 0:
            raise ValueError("invalid circuit breaker settings")
