from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import AsyncIterator

from app.providers.base import ProviderError


@dataclass(slots=True)
class AdmissionSnapshot:
    active: int
    waiting: int
    rejected: int
    peak_active_or_waiting: int
    peak_queue_length: int


class BoundedAdmission:
    """Bounds total admitted work while a semaphore bounds active provider calls."""

    def __init__(self, max_in_flight: int, max_queue: int, queue_wait_seconds: float):
        self._semaphore = asyncio.Semaphore(max_in_flight)
        self._max_total = max_in_flight + max_queue
        self._max_in_flight = max_in_flight
        self._queue_wait_seconds = queue_wait_seconds
        self._lock = asyncio.Lock()
        self._admitted = 0
        self._active = 0
        self._waiting = 0
        self._rejected = 0
        self._peak = 0
        self._peak_queue = 0

    @asynccontextmanager
    async def slot(self, *, total_deadline_remaining: float | None = None) -> AsyncIterator[None]:
        async with self._lock:
            if self._admitted >= self._max_total:
                self._rejected += 1
                raise ProviderError(
                    "The request queue is full; retry later.",
                    status_code=503,
                    error_code="queue_full",
                    retryable=False,
                )
            self._admitted += 1
            self._peak = max(self._peak, self._admitted)
            waiting_counted = self._semaphore.locked()
            if waiting_counted:
                self._waiting += 1
                self._peak_queue = max(self._peak_queue, self._waiting)

        acquired = False
        try:
            wait_timeout = self._queue_wait_seconds
            if total_deadline_remaining is not None:
                wait_timeout = min(wait_timeout, max(0.001, total_deadline_remaining))
            try:
                async with asyncio.timeout(wait_timeout):
                    await self._semaphore.acquire()
                acquired = True
            except TimeoutError as exc:
                async with self._lock:
                    self._rejected += 1
                raise ProviderError(
                    "The request exceeded the queue wait deadline.",
                    status_code=503,
                    error_code="queue_wait_timeout",
                    retryable=False,
                ) from exc
            async with self._lock:
                if waiting_counted:
                    self._waiting = max(0, self._waiting - 1)
                    waiting_counted = False
                self._active += 1
            yield
        finally:
            if acquired:
                self._semaphore.release()
                async with self._lock:
                    self._active = max(0, self._active - 1)
            async with self._lock:
                if waiting_counted:
                    self._waiting = max(0, self._waiting - 1)
                self._admitted = max(0, self._admitted - 1)

    async def snapshot(self) -> AdmissionSnapshot:
        async with self._lock:
            return AdmissionSnapshot(
                active=self._active,
                waiting=self._waiting,
                rejected=self._rejected,
                peak_active_or_waiting=self._peak,
                peak_queue_length=self._peak_queue,
            )
