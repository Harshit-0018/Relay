from __future__ import annotations

import asyncio
import email.utils
import logging
import random
import time
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from typing import Any

from app.providers.base import CompletionResult, LLMProvider, ProviderError
from app.reliability.admission import BoundedAdmission
from app.reliability.circuit_breaker import CircuitBreaker
from app.reliability.config import ReliabilityConfig

logger = logging.getLogger("the_relay.reliability")


class ResilientProvider:
    """Adds bounded admission, deadlines, retry policy and circuit breaking."""

    def __init__(self, provider: LLMProvider, config: ReliabilityConfig):
        self.provider = provider
        self.config = config
        self.name = provider.name
        self.model = provider.model
        self.admission = BoundedAdmission(config.max_in_flight, config.max_queue, config.queue_wait_seconds)
        self.breaker = CircuitBreaker(config.circuit_failure_threshold, config.circuit_recovery_seconds)
        self._rng = random.Random(config.random_seed)
        self._stats_lock = asyncio.Lock()
        self._stats: dict[str, int] = {"calls": 0, "retries": 0, "timeouts": 0, "failures": 0}

    @staticmethod
    def _retry_after_seconds(value: str | None) -> float | None:
        if not value:
            return None
        try:
            return max(0.0, float(value))
        except ValueError:
            try:
                parsed = email.utils.parsedate_to_datetime(value)
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=timezone.utc)
                return max(0.0, (parsed - datetime.now(timezone.utc)).total_seconds())
            except (TypeError, ValueError, OverflowError):
                return None

    async def _inc(self, name: str) -> None:
        async with self._stats_lock:
            self._stats[name] = self._stats.get(name, 0) + 1

    async def _delay(self, attempt: int, retry_after: str | None) -> float:
        header_delay = self._retry_after_seconds(retry_after)
        if header_delay is not None:
            # Retry-After is authoritative; do not silently retry earlier than requested.
            return header_delay
        base = min(self.config.retry_max_seconds, self.config.retry_base_seconds * (2 ** attempt))
        jitter = self._rng.uniform(0.0, self.config.retry_jitter)
        return min(self.config.retry_max_seconds, base + jitter)

    async def _execute(self, operation, *, operation_name: str) -> Any:
        last_error: ProviderError | None = None
        total_deadline = time.perf_counter() + self.config.provider_deadline_seconds
        for attempt in range(self.config.max_retries + 1):
            await self.breaker.before_call()
            remaining = total_deadline - time.perf_counter()
            if remaining <= 0:
                raise ProviderError(
                    f"Provider {operation_name} exceeded its overall deadline.",
                    status_code=504, error_code="provider_deadline_exceeded", retryable=False,
                )
            async with self.admission.slot(total_deadline_remaining=remaining):
                await self._inc("calls")
                started = time.perf_counter()
                try:
                    operation_remaining = total_deadline - time.perf_counter()
                    if operation_remaining <= 0:
                        raise TimeoutError("deadline expired while waiting for admission")
                    async with asyncio.timeout(operation_remaining):
                        result = await operation()
                    await self.breaker.record_success()
                    return result
                except asyncio.CancelledError:
                    # Cancellation is intentional (client disconnect/shutdown); release capacity and propagate.
                    raise
                except TimeoutError as exc:
                    await self._inc("timeouts")
                    last_error = ProviderError(
                        f"Provider {operation_name} exceeded its deadline.",
                        status_code=504,
                        error_code="provider_deadline_exceeded",
                        retryable=True,
                    )
                    last_error.__cause__ = exc
                except ProviderError as exc:
                    last_error = exc
                except Exception as exc:  # normalize unexpected SDK/transport exceptions
                    last_error = ProviderError(
                        f"Unexpected provider error: {type(exc).__name__}: {exc}",
                        status_code=502,
                        error_code="provider_unexpected_error",
                        retryable=False,
                    )
                    last_error.__cause__ = exc

            assert last_error is not None
            await self._inc("failures")
            count_for_breaker = last_error.status_code is not None and last_error.status_code >= 500
            await self.breaker.record_failure(count_toward_open=count_for_breaker)
            if not last_error.retryable or attempt >= self.config.max_retries:
                logger.warning(
                    "provider_call_failed",
                    extra={"operation": operation_name, "attempt": attempt + 1,
                           "error_code": last_error.error_code, "status_code": last_error.status_code,
                           "elapsed_ms": round((time.perf_counter() - started) * 1000, 2)},
                )
                raise last_error
            await self._inc("retries")
            delay = await self._delay(attempt, last_error.retry_after)
            remaining = total_deadline - time.perf_counter()
            if delay >= remaining:
                raise last_error
            logger.info("provider_retry", extra={"operation": operation_name, "attempt": attempt + 1, "delay_seconds": delay})
            await asyncio.sleep(delay)
        raise last_error or RuntimeError("unreachable provider retry state")

    async def complete(self, messages, *, temperature: float, max_completion_tokens: int) -> CompletionResult:
        return await self._execute(
            lambda: self.provider.complete(
                messages, temperature=temperature, max_completion_tokens=max_completion_tokens
            ),
            operation_name="complete",
        )

    async def _collect_stream(self, messages, *, temperature: float, max_completion_tokens: int) -> list[str]:
        pieces: list[str] = []
        async for piece in self.provider.stream(
            messages, temperature=temperature, max_completion_tokens=max_completion_tokens
        ):
            pieces.append(piece)
        return pieces

    async def stream(self, messages, *, temperature: float, max_completion_tokens: int) -> AsyncIterator[str]:
        # Buffer one complete attempt before yielding so a retry cannot duplicate user-visible text.
        pieces = await self._execute(
            lambda: self._collect_stream(
                messages, temperature=temperature, max_completion_tokens=max_completion_tokens
            ),
            operation_name="stream",
        )
        for piece in pieces:
            yield piece

    async def metrics(self) -> dict[str, Any]:
        admission = await self.admission.snapshot()
        breaker = await self.breaker.snapshot()
        async with self._stats_lock:
            stats = dict(self._stats)
        provider_metrics = None
        if hasattr(self.provider, "metrics"):
            try:
                provider_metrics = await self.provider.metrics()
            except Exception:
                provider_metrics = {"status": "unavailable"}
        return {
            "provider": self.name,
            "model": self.model,
            "calls": stats["calls"],
            "retries": stats["retries"],
            "timeouts": stats["timeouts"],
            "failures": stats["failures"],
            "admission": {
                "active": admission.active,
                "waiting": admission.waiting,
                "rejected": admission.rejected,
                "peak_active_or_waiting": admission.peak_active_or_waiting,
                "peak_queue_length": admission.peak_queue_length,
            },
            "circuit_breaker": breaker,
            "provider_service": provider_metrics,
        }
