from __future__ import annotations

import asyncio
import time

from app.providers.base import ProviderError


class CircuitBreaker:
    """Small process-local breaker: closed -> open -> one half-open probe."""

    def __init__(self, failure_threshold: int, recovery_seconds: float):
        self.failure_threshold = failure_threshold
        self.recovery_seconds = recovery_seconds
        self._lock = asyncio.Lock()
        self._failures = 0
        self._opened_at: float | None = None
        self._probe_in_progress = False

    async def before_call(self) -> None:
        async with self._lock:
            if self._opened_at is None:
                return
            if time.monotonic() - self._opened_at < self.recovery_seconds:
                raise ProviderError(
                    "The provider circuit is open; requests are temporarily rejected.",
                    status_code=503,
                    error_code="circuit_open",
                    retryable=False,
                )
            if self._probe_in_progress:
                raise ProviderError(
                    "The provider circuit is half-open and a recovery probe is already running.",
                    status_code=503,
                    error_code="circuit_probe_busy",
                    retryable=False,
                )
            self._probe_in_progress = True

    async def record_success(self) -> None:
        async with self._lock:
            self._failures = 0
            self._opened_at = None
            self._probe_in_progress = False

    async def record_failure(self, *, count_toward_open: bool) -> None:
        async with self._lock:
            self._probe_in_progress = False
            if not count_toward_open:
                return
            self._failures += 1
            if self._failures >= self.failure_threshold:
                self._opened_at = time.monotonic()

    async def snapshot(self) -> dict[str, object]:
        async with self._lock:
            if self._opened_at is None:
                state = "closed"
            elif time.monotonic() - self._opened_at < self.recovery_seconds:
                state = "open"
            else:
                state = "half_open"
            return {"state": state, "consecutive_failures": self._failures}
