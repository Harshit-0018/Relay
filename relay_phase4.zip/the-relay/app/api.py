from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse

from app.api_schemas import AskRequest, AskResponse
from app.config import Settings
from app.providers.base import ProviderError
from app.services.factory import create_pipeline
from app.services.pipeline import PaperQAPipeline


def create_app(*, pipeline: PaperQAPipeline | None = None, settings: Settings | None = None) -> FastAPI:
    app = FastAPI(
        title="The Relay",
        version="0.3.0",
        description="Evidence-grounded question answering over the approved research-paper library.",
    )
    app.state.relay_pipeline = pipeline
    app.state.relay_settings = settings or Settings.from_env()

    def get_pipeline() -> PaperQAPipeline:
        current = app.state.relay_pipeline
        if current is None:
            try:
                current = create_pipeline(app.state.relay_settings)
            except FileNotFoundError as exc:
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            except ValueError as exc:
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            app.state.relay_pipeline = current
        return current

    @app.get("/health")
    async def health() -> dict[str, Any]:
        configured = app.state.relay_settings
        chunks_exist = configured.chunks_path.exists()
        return {
            "status": "ok" if chunks_exist else "waiting_for_paper_ingestion",
            "service": "the-relay",
            "provider_mode": configured.provider_mode,
            "paper_library_ready": chunks_exist,
            "chunks_path": str(configured.chunks_path),
            "reliability": {
                "max_in_flight": configured.max_in_flight,
                "max_queue": configured.max_queue,
                "provider_deadline_seconds": configured.provider_deadline_seconds,
                "max_provider_retries": configured.max_provider_retries,
            },
        }


    @app.get("/internal/reliability")
    async def reliability_metrics() -> dict[str, Any]:
        current = app.state.relay_pipeline
        if current is None:
            return {"status": "not_initialized", "message": "Metrics become available after the pipeline is initialized."}
        provider = current.provider
        if hasattr(provider, "metrics"):
            return {"status": "ok", "metrics": await provider.metrics()}
        return {"status": "unavailable", "message": "The injected provider does not expose reliability metrics."}

    @app.post("/v1/ask", response_model=AskResponse)
    async def ask(request: AskRequest) -> AskResponse:
        relay = get_pipeline()
        try:
            result = await relay.answer(request.question, top_k=request.top_k)
            return AskResponse(**result.to_dict())
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        except ProviderError as exc:
            status = exc.status_code if exc.status_code in {429, 502, 503, 504} else 502
            headers = {"Retry-After": exc.retry_after} if exc.retry_after else None
            raise HTTPException(
                status_code=status,
                detail={"message": str(exc), "code": exc.error_code, "limit_scope": exc.limit_scope},
                headers=headers,
            ) from exc

    @app.post("/v1/ask/stream")
    async def ask_stream(request: AskRequest) -> StreamingResponse:
        relay = get_pipeline()
        started = time.perf_counter()

        async def event_stream() -> AsyncIterator[str]:
            try:
                # Generate and verify the complete draft before releasing any answer text.
                # This preserves the assignment's check-before-send requirement.
                result = await relay.answer(request.question, top_k=request.top_k, use_upstream_stream=True)
                yield "data: " + json.dumps({
                    "type": "meta",
                    "request_id": result.request_id,
                    "verification_status": result.verification_status,
                    "verification_before_delivery": True,
                }) + "\n\n"
                answer = result.answer
                for offset in range(0, len(answer), 72):
                    yield "data: " + json.dumps({"type": "token", "text": answer[offset:offset + 72]}) + "\n\n"
                yield "data: " + json.dumps({
                    "type": "done",
                    "citations": result.citations,
                    "refused": result.refused,
                    "provider": result.provider,
                    "model": result.model,
                    "retrieved_chunks": result.retrieved_chunks,
                    "total_ms": result.total_ms,
                    "time_to_verified_first_chunk_ms": round((time.perf_counter() - started) * 1000, 2),
                }) + "\n\n"
            except ProviderError as exc:  # SSE has already started; return a structured error event.
                yield "data: " + json.dumps({
                    "type": "error", "error": str(exc), "code": exc.error_code,
                    "status_code": exc.status_code, "retry_after": exc.retry_after,
                }) + "\n\n"
            except Exception as exc:  # SSE has already started; return a structured error event.
                yield "data: " + json.dumps({"type": "error", "error": str(exc)}) + "\n\n"

        return StreamingResponse(event_stream(), media_type="text/event-stream", headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        })

    return app


app = create_app()
