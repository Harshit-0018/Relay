from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator, Protocol


@dataclass(slots=True)
class CompletionResult:
    content: str
    model: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    finish_reason: str | None = None


class ProviderError(RuntimeError):
    """Provider failure with enough metadata for safe retry decisions."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        retry_after: str | None = None,
        error_code: str | None = None,
        retryable: bool | None = None,
        limit_scope: str | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.retry_after = retry_after
        self.error_code = error_code
        self.retryable = retryable if retryable is not None else status_code in {408, 425, 429, 500, 502, 503, 504}
        self.limit_scope = limit_scope


class LLMProvider(Protocol):
    name: str
    model: str

    async def complete(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_completion_tokens: int,
    ) -> CompletionResult: ...

    def stream(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_completion_tokens: int,
    ) -> AsyncIterator[str]: ...
