from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from app.providers.base import CompletionResult
from simulator.service import SimulatedModelService, SimulatorConfig


class StandInProvider:
    """LLMProvider adapter over the configurable local stand-in model service."""

    name = "standin"

    def __init__(self, service: SimulatedModelService | None = None, config: SimulatorConfig | None = None):
        self.service = service or SimulatedModelService(config)
        self.model = self.service.config.model

    async def complete(self, messages, *, temperature: float, max_completion_tokens: int) -> CompletionResult:
        del temperature
        return await self.service.complete(messages, max_completion_tokens=max_completion_tokens)

    async def stream(self, messages, *, temperature: float, max_completion_tokens: int) -> AsyncIterator[str]:
        del temperature
        async for piece in self.service.stream(messages, max_completion_tokens=max_completion_tokens):
            yield piece

    async def metrics(self) -> dict[str, Any]:
        return await self.service.metrics()
