from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from app.providers.base import CompletionResult, ProviderError


class GroqProvider:
    """Small async adapter for Groq's OpenAI-compatible Chat Completions API."""

    name = "groq"

    def __init__(self, api_key: str, model: str, base_url: str, timeout_seconds: float = 45.0) -> None:
        if not api_key:
            raise ValueError("GROQ_API_KEY is missing. Add it to .env before using PROVIDER_MODE=groq.")
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    def _payload(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_completion_tokens: int,
        stream: bool = False,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_completion_tokens": max_completion_tokens,
            "stream": stream,
        }
        if stream:
            payload["stream_options"] = {"include_usage": True}
        return payload

    @staticmethod
    def _raise_for_provider_error(response: httpx.Response) -> None:
        if response.is_success:
            return
        try:
            body = response.json()
            message = body.get("error", {}).get("message") or body.get("message") or str(body)
        except (ValueError, AttributeError):
            message = response.text[:1000]
        lowered = message.lower()
        daily_limit = response.status_code == 429 and any(
            marker in lowered for marker in ("per day", "daily limit", "daily quota", "requests per day", "tokens per day")
        )
        raise ProviderError(
            f"Groq API returned HTTP {response.status_code}: {message}",
            status_code=response.status_code,
            retry_after=response.headers.get("retry-after"),
            error_code="daily_budget_exhausted" if daily_limit else "groq_rate_limit" if response.status_code == 429 else "groq_http_error",
            retryable=False if daily_limit else response.status_code in {408, 425, 429, 500, 502, 503, 504},
            limit_scope="day" if daily_limit else "minute" if response.status_code == 429 else None,
        )

    async def complete(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_completion_tokens: int,
    ) -> CompletionResult:
        timeout = httpx.Timeout(self.timeout_seconds)
        async with httpx.AsyncClient(timeout=timeout) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/chat/completions",
                    headers=self._headers,
                    json=self._payload(
                        messages,
                        temperature=temperature,
                        max_completion_tokens=max_completion_tokens,
                    ),
                )
            except httpx.TimeoutException as exc:
                raise ProviderError(
                    f"Groq request timed out after {self.timeout_seconds:g}s", status_code=504,
                    error_code="groq_timeout", retryable=True,
                ) from exc
            except httpx.HTTPError as exc:
                raise ProviderError(
                    f"Groq transport error: {exc}", status_code=502,
                    error_code="groq_transport_error", retryable=True,
                ) from exc
        self._raise_for_provider_error(response)
        try:
            data = response.json()
            choice = data["choices"][0]
            usage = data.get("usage") or {}
            content = choice.get("message", {}).get("content") or ""
            return CompletionResult(
                content=content,
                model=data.get("model", self.model),
                input_tokens=usage.get("prompt_tokens"),
                output_tokens=usage.get("completion_tokens"),
                finish_reason=choice.get("finish_reason"),
            )
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            raise ProviderError("Groq returned an unexpected completion response") from exc

    async def stream(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_completion_tokens: int,
    ) -> AsyncIterator[str]:
        timeout = httpx.Timeout(self.timeout_seconds)
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream(
                    "POST",
                    f"{self.base_url}/chat/completions",
                    headers=self._headers,
                    json=self._payload(
                        messages,
                        temperature=temperature,
                        max_completion_tokens=max_completion_tokens,
                        stream=True,
                    ),
                ) as response:
                    if not response.is_success:
                        body = (await response.aread()).decode("utf-8", errors="replace")
                        try:
                            parsed = json.loads(body)
                            message = parsed.get("error", {}).get("message") or body[:1000]
                        except (ValueError, AttributeError):
                            message = body[:1000]
                        raise ProviderError(
                            f"Groq API returned HTTP {response.status_code}: {message}",
                            status_code=response.status_code,
                            retry_after=response.headers.get("retry-after"),
                        )
                    async for line in response.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        payload = line[5:].strip()
                        if payload == "[DONE]":
                            break
                        try:
                            event = json.loads(payload)
                        except json.JSONDecodeError:
                            continue
                        choices = event.get("choices") or []
                        if choices:
                            delta = choices[0].get("delta", {}).get("content")
                            if isinstance(delta, str) and delta:
                                yield delta
        except httpx.TimeoutException as exc:
            raise ProviderError(
                f"Groq stream timed out after {self.timeout_seconds:g}s", status_code=504,
                error_code="groq_stream_timeout", retryable=True,
            ) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(
                f"Groq streaming transport error: {exc}", status_code=502,
                error_code="groq_stream_transport_error", retryable=True,
            ) from exc
