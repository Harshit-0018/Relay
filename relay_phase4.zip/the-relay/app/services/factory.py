from __future__ import annotations

from app.config import Settings
from app.providers.demo_provider import DemoProvider
from app.providers.groq_provider import GroqProvider
from app.providers.standin_provider import StandInProvider
from app.retrieval.tool import PaperSearchTool
from app.services.pipeline import PaperQAPipeline
from app.reliability.config import ReliabilityConfig
from app.reliability.resilient_provider import ResilientProvider
from simulator.service import SimulatedModelService, SimulatorConfig


def create_pipeline(settings: Settings | None = None) -> PaperQAPipeline:
    settings = settings or Settings.from_env()
    if settings.provider_mode == "groq":
        provider = GroqProvider(
            api_key=settings.groq_api_key,
            model=settings.groq_model,
            base_url=settings.groq_base_url,
            timeout_seconds=settings.request_timeout_seconds,
        )
    elif settings.provider_mode == "standin":
        provider = StandInProvider(SimulatedModelService(SimulatorConfig.from_env()))
    else:
        provider = DemoProvider()

    reliability = ReliabilityConfig(
        max_in_flight=settings.max_in_flight,
        max_queue=settings.max_queue,
        queue_wait_seconds=settings.queue_wait_seconds,
        provider_deadline_seconds=settings.provider_deadline_seconds,
        max_retries=settings.max_provider_retries,
        retry_base_seconds=settings.retry_base_seconds,
        retry_max_seconds=settings.retry_max_seconds,
        retry_jitter=settings.retry_jitter,
        circuit_failure_threshold=settings.circuit_failure_threshold,
        circuit_recovery_seconds=settings.circuit_recovery_seconds,
        random_seed=settings.reliability_seed,
    )
    protected_provider = ResilientProvider(provider, reliability)
    retrieval_tool = PaperSearchTool(settings.chunks_path)
    return PaperQAPipeline(retrieval_tool, protected_provider, settings)
