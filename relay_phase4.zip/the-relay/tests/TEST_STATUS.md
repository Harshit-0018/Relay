# Test Status — Cumulative Phases 1–4

Executed in the build environment on 2026-11-12 with Python 3.13.5 and pytest.

- **Passed:** 50
- **Failed:** 0
- **Skipped:** 0
- `python -m compileall -q app simulator scripts experiments tests`: passed.
- `python -m app.cli --help`: passed.
- `python -m pytest`: **50 passed**.
- `python -m experiments.run_load_benchmark`: executed five scenarios and wrote 116 request rows.
- `python -m experiments.retrieval_benchmark`: created three retrieval-setting rows; paper-backed retrieval metrics are marked not measured because exact-version PDFs are unavailable.
- `python -m experiments.run_real_groq_probe`: did not send a request because `GROQ_API_KEY` was not configured.
- `python -m experiments.build_report_tables`: generated Tables 1, 2a, 2b and 3, `metrics.json`, the experiment manifest and report-ready Markdown.
- `python scripts/retry_storm_demo.py`: passed; `no_retry_rate_limited=0`, `with_retry_rate_limited=1` under the demonstration's two-request RPM budget.

## Phase 4 scenario outcomes

| Scenario | Requests | Succeeded | Rate-limited | Timeout/error |
|---|---:|---:|---:|---:|
| Steady | 20 | 20 | 0 | 0 |
| Burst | 24 | 24 | 0 | 0 |
| Sustained overload | 40 | 8 | 32 | 0 |
| Per-minute limit halved | 20 | 5 | 15 | 0 |
| Daily budget exhausted | 12 | 4 | 8 | 0 |

No factual answer grade was assigned to stand-in completions. No real Groq or paper-backed answer-quality test was claimed as successful.

## Required local actions

1. Download the exact PDFs with `python scripts/download_papers.py` (the build environment's outbound download attempt failed).
2. Run `python -m app.cli ingest`.
3. Configure `GROQ_API_KEY` in `.env`.
4. Check the current organization limits in Groq Console.
5. Explicitly run `python -m experiments.run_real_groq_probe --run --max-requests 3` for the small live baseline.
6. Run `python -m experiments.retrieval_benchmark --with-groq --max-questions 15` for paper-backed LLM answer evaluation, only when quota permits.
