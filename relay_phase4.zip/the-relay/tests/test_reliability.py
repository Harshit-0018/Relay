from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from app.config import Settings
from app.providers.base import CompletionResult, ProviderError
from app.providers.standin_provider import StandInProvider
from app.reliability.config import ReliabilityConfig
from app.reliability.resilient_provider import ResilientProvider
from app.retrieval.schemas import Chunk
from app.retrieval.store import save_chunks
from app.retrieval.tool import PaperSearchTool
from app.services.pipeline import PaperQAPipeline
from simulator.service import SimulatedModelService, SimulatorConfig


class AlwaysFails:
    name = "fails"
    model = "fails-v1"

    async def complete(self, messages, *, temperature, max_completion_tokens):
        del messages, temperature, max_completion_tokens
        raise ProviderError("temporary outage", status_code=503, error_code="test_outage", retryable=True)

    async def stream(self, messages, *, temperature, max_completion_tokens):
        del messages, temperature, max_completion_tokens
        raise ProviderError("temporary outage", status_code=503, error_code="test_outage", retryable=True)
        yield "unreachable"


class SlowProvider:
    name = "slow"
    model = "slow-v1"

    def __init__(self):
        self.cancelled = False

    async def complete(self, messages, *, temperature, max_completion_tokens):
        del messages, temperature, max_completion_tokens
        try:
            await asyncio.sleep(1)
        except asyncio.CancelledError:
            self.cancelled = True
            raise
        return CompletionResult("done", self.model)

    async def stream(self, messages, *, temperature, max_completion_tokens):
        result = await self.complete(messages, temperature=temperature, max_completion_tokens=max_completion_tokens)
        yield result.content


def reliability(**overrides):
    values = dict(
        max_in_flight=2, max_queue=4, queue_wait_seconds=0.2,
        provider_deadline_seconds=0.5, max_retries=0,
        retry_base_seconds=0.001, retry_max_seconds=0.01,
        circuit_failure_threshold=3, circuit_recovery_seconds=0.05,
    )
    values.update(overrides)
    return ReliabilityConfig(**values)


@pytest.mark.asyncio
async def test_standin_returns_simulated_response_and_metrics():
    provider = StandInProvider(service=SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=2, overload_threshold=1, random_seed=1,
    )))
    result = await provider.complete(
        [{"role": "user", "content": "Question with evidence [E1] [Attention Is All You Need, arXiv:1706.03762v7, PDF p. 3]"}],
        temperature=0, max_completion_tokens=80,
    )
    assert "STAND-IN SIMULATION" in result.content
    assert result.input_tokens and result.output_tokens
    metrics = await provider.metrics()
    assert metrics["succeeded"] == 1
    assert metrics["requests"] == 1


@pytest.mark.asyncio
async def test_standin_enforces_minute_limit():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=1, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=2, random_seed=2,
    ))
    await service.complete([{"role": "user", "content": "one"}], max_completion_tokens=20)
    with pytest.raises(ProviderError) as caught:
        await service.complete([{"role": "user", "content": "two"}], max_completion_tokens=20)
    assert caught.value.error_code == "minute_request_rate_limit"
    assert caught.value.retryable is True
    assert caught.value.retry_after


@pytest.mark.asyncio
async def test_standin_daily_limit_is_not_retryable():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=1, tokens_per_day=100000,
        max_concurrent=2, random_seed=3,
    ))
    await service.complete([{"role": "user", "content": "one"}], max_completion_tokens=20)
    with pytest.raises(ProviderError) as caught:
        await service.complete([{"role": "user", "content": "two"}], max_completion_tokens=20)
    assert caught.value.error_code == "daily_request_budget_exhausted"
    assert caught.value.retryable is False


@pytest.mark.asyncio
async def test_simulator_streams_in_multiple_pieces():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=2, stream_chunk_chars=10, stream_chunk_interval_seconds=0,
    ))
    pieces = [piece async for piece in service.stream([{"role": "user", "content": "stream"}], max_completion_tokens=40)]
    assert len(pieces) > 1
    assert "".join(pieces).startswith("STAND-IN SIMULATION")


@pytest.mark.asyncio
async def test_resilient_provider_retries_transient_failure():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        fail_first_n=1, rpm_limit=10, tpm_limit=10000, requests_per_day=20,
        tokens_per_day=100000, max_concurrent=2, random_seed=4,
    ))
    wrapped = ResilientProvider(StandInProvider(service), reliability(max_retries=1))
    result = await wrapped.complete([{"role": "user", "content": "retry"}], temperature=0, max_completion_tokens=50)
    assert "STAND-IN SIMULATION" in result.content
    metrics = await wrapped.metrics()
    assert metrics["retries"] == 1
    assert metrics["provider_service"]["failed"] == 1
    assert metrics["provider_service"]["succeeded"] == 1


@pytest.mark.asyncio
async def test_daily_exhaustion_is_not_retried_by_wrapper():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=1, tokens_per_day=100000,
        max_concurrent=2, random_seed=5,
    ))
    wrapped = ResilientProvider(StandInProvider(service), reliability(max_retries=3))
    await wrapped.complete([{"role": "user", "content": "first"}], temperature=0, max_completion_tokens=20)
    with pytest.raises(ProviderError) as caught:
        await wrapped.complete([{"role": "user", "content": "second"}], temperature=0, max_completion_tokens=20)
    assert caught.value.error_code == "daily_request_budget_exhausted"
    metrics = await wrapped.metrics()
    assert metrics["retries"] == 0


@pytest.mark.asyncio
async def test_provider_deadline_cancels_slow_call_and_releases_slot():
    slow = SlowProvider()
    wrapped = ResilientProvider(slow, reliability(provider_deadline_seconds=0.03, max_in_flight=1))
    with pytest.raises(ProviderError) as caught:
        await wrapped.complete([], temperature=0, max_completion_tokens=10)
    assert caught.value.status_code == 504
    assert slow.cancelled is True
    metrics = await wrapped.metrics()
    assert metrics["admission"]["active"] == 0


@pytest.mark.asyncio
async def test_bounded_queue_rejects_over_capacity_without_leaking_slots():
    slow = SlowProvider()
    wrapped = ResilientProvider(slow, reliability(
        max_in_flight=1, max_queue=0, provider_deadline_seconds=2, max_retries=0,
    ))
    first = asyncio.create_task(wrapped.complete([], temperature=0, max_completion_tokens=10))
    await asyncio.sleep(0.01)
    with pytest.raises(ProviderError) as caught:
        await wrapped.complete([], temperature=0, max_completion_tokens=10)
    assert caught.value.error_code == "queue_full"
    first.cancel()
    with pytest.raises(asyncio.CancelledError):
        await first
    metrics = await wrapped.metrics()
    assert metrics["admission"]["active"] == 0
    assert metrics["admission"]["rejected"] == 1


@pytest.mark.asyncio
async def test_circuit_breaker_opens_after_configured_server_failures():
    wrapped = ResilientProvider(AlwaysFails(), reliability(
        circuit_failure_threshold=2, max_retries=0,
    ))
    for _ in range(2):
        with pytest.raises(ProviderError):
            await wrapped.complete([], temperature=0, max_completion_tokens=10)
    with pytest.raises(ProviderError) as caught:
        await wrapped.complete([], temperature=0, max_completion_tokens=10)
    assert caught.value.error_code == "circuit_open"


@pytest.mark.asyncio
async def test_pipeline_can_use_standin_provider_without_groq_key(tmp_path: Path):
    chunk = Chunk(
        chunk_id="phase3-chunk", paper_id="attention", title="Attention Is All You Need",
        arxiv_id="1706.03762", version=7, pdf_filename="1706.03762v7.pdf",
        pdf_page=3, printed_page=None, section="1 Introduction", chunk_index_on_page=0,
        text="The Transformer relies entirely on attention mechanisms.",
    )
    chunks_path = tmp_path / "chunks.jsonl"
    save_chunks(chunks_path, [chunk])
    provider = ResilientProvider(StandInProvider(service=SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=2, random_seed=8,
    ))), reliability(max_retries=0))
    settings = Settings(provider_mode="standin", chunks_path=chunks_path)
    pipeline = PaperQAPipeline(PaperSearchTool(chunks_path), provider, settings)
    result = await pipeline.answer("What does the Transformer rely on?")
    assert result.refused is False
    assert result.provider == "standin"
    assert result.verification_status == "citation_provenance_validated"


@pytest.mark.asyncio
async def test_retries_can_consume_capacity_and_rate_limit_later_requests():
    # The first upstream request fails once. With retries enabled, its retry consumes
    # the second RPM slot, so the next user's request is rate-limited.
    async def run(max_retries: int) -> int:
        service = SimulatedModelService(SimulatorConfig(
            base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
            fail_first_n=1, rpm_limit=2, tpm_limit=10000, requests_per_day=100,
            tokens_per_day=100000, max_concurrent=10, random_seed=9,
        ))
        provider = ResilientProvider(StandInProvider(service), reliability(
            max_retries=max_retries, retry_base_seconds=0.001, retry_max_seconds=0.002,
            provider_deadline_seconds=0.5,
        ))
        for text in ("first user request", "second user request"):
            try:
                await provider.complete([{"role": "user", "content": text}], temperature=0, max_completion_tokens=20)
            except ProviderError:
                pass
        metrics = await service.metrics()
        return metrics["rate_limited"]

    rejected_without_retry = await run(0)
    rejected_with_retry = await run(2)
    assert rejected_without_retry == 0
    assert rejected_with_retry == 1


@pytest.mark.asyncio
async def test_resilient_stream_retries_before_releasing_any_partial_text():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        fail_first_n=1, rpm_limit=10, tpm_limit=10000, requests_per_day=20,
        tokens_per_day=100000, max_concurrent=2, stream_chunk_chars=12,
        stream_chunk_interval_seconds=0, random_seed=14,
    ))
    wrapped = ResilientProvider(StandInProvider(service), reliability(max_retries=1))
    pieces = [piece async for piece in wrapped.stream(
        [{"role": "user", "content": "stream and retry"}], temperature=0, max_completion_tokens=60
    )]
    text = "".join(pieces)
    assert text.count("STAND-IN SIMULATION") == 1
    metrics = await wrapped.metrics()
    assert metrics["retries"] == 1
    assert metrics["provider_service"]["failed"] == 1
    assert metrics["provider_service"]["succeeded"] == 1


def test_standalone_simulator_api_openai_compatible_response(monkeypatch):
    from fastapi.testclient import TestClient
    import simulator.api as simulator_api

    monkeypatch.setattr(simulator_api, "service", SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=2, random_seed=15,
    )))
    client = TestClient(simulator_api.app)
    response = client.post("/v1/chat/completions", json={
        "model": "relay-standin-v1",
        "messages": [{"role": "user", "content": "hello"}],
        "max_tokens": 50,
        "stream": False,
    })
    assert response.status_code == 200
    body = response.json()
    assert body["object"] == "chat.completion"
    assert "STAND-IN SIMULATION" in body["choices"][0]["message"]["content"]
    assert body["usage"]["total_tokens"] > 0
    stream_response = client.post("/v1/chat/completions", json={
        "model": "relay-standin-v1",
        "messages": [{"role": "user", "content": "hello stream"}],
        "max_tokens": 50,
        "stream": True,
    })
    assert stream_response.status_code == 200
    assert "chat.completion.chunk" in stream_response.text
    assert "[DONE]" in stream_response.text


@pytest.mark.asyncio
async def test_standin_timeout_every_n_produces_timeout_without_waiting_full_latency():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.01, latency_jitter_seconds=0, slow_tail_probability=0,
        timeout_every_n=1, simulated_timeout_seconds=0.005,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=2, random_seed=16,
    ))
    started = asyncio.get_running_loop().time()
    with pytest.raises(ProviderError) as caught:
        await service.complete([{"role": "user", "content": "timeout"}], max_completion_tokens=20)
    elapsed = asyncio.get_running_loop().time() - started
    assert caught.value.error_code == "simulated_timeout"
    assert elapsed < 0.1
    metrics = await service.metrics()
    assert metrics["timed_out"] == 1


@pytest.mark.asyncio
async def test_factory_api_runs_in_standin_mode_without_groq_key(tmp_path):
    from fastapi.testclient import TestClient
    from app.api import create_app
    from app.services.factory import create_pipeline

    chunk = Chunk(
        chunk_id="factory-chunk", paper_id="attention", title="Attention Is All You Need",
        arxiv_id="1706.03762", version=7, pdf_filename="1706.03762v7.pdf",
        pdf_page=3, printed_page=None, section="1 Introduction", chunk_index_on_page=0,
        text="The Transformer architecture relies entirely on attention mechanisms.",
    )
    chunks_path = tmp_path / "factory_chunks.jsonl"
    save_chunks(chunks_path, [chunk])
    settings = Settings(
        provider_mode="standin", groq_api_key="", chunks_path=chunks_path,
        max_provider_retries=0,
    )
    pipeline = create_pipeline(settings)
    response = TestClient(create_app(pipeline=pipeline, settings=settings)).post(
        "/v1/ask", json={"question": "What does the Transformer rely on?"}
    )
    assert response.status_code == 200
    body = response.json()
    assert body["provider"] == "standin"
    assert body["refused"] is False
    assert body["citations"]


@pytest.mark.asyncio
async def test_standin_enforces_tpm_and_daily_token_budgets():
    minute_limited = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=3, requests_per_day=20, tokens_per_day=100000,
        completion_reservation_tokens=1, max_concurrent=2, random_seed=17,
    ))
    await minute_limited.complete([{"role": "user", "content": "x"}], max_completion_tokens=1)
    with pytest.raises(ProviderError) as minute_error:
        await minute_limited.complete([{"role": "user", "content": "y"}], max_completion_tokens=1)
    assert minute_error.value.error_code == "minute_token_rate_limit"

    daily_limited = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=3,
        completion_reservation_tokens=1, max_concurrent=2, random_seed=18,
    ))
    await daily_limited.complete([{"role": "user", "content": "x"}], max_completion_tokens=1)
    with pytest.raises(ProviderError) as daily_error:
        await daily_limited.complete([{"role": "user", "content": "y"}], max_completion_tokens=1)
    assert daily_error.value.error_code == "daily_token_budget_exhausted"
    assert daily_error.value.retryable is False


@pytest.mark.asyncio
async def test_standin_enforces_concurrency_limit():
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.06, latency_jitter_seconds=0, slow_tail_probability=0,
        rpm_limit=10, tpm_limit=10000, requests_per_day=20, tokens_per_day=100000,
        max_concurrent=1, random_seed=19,
    ))
    first = asyncio.create_task(service.complete([{"role": "user", "content": "first"}], max_completion_tokens=10))
    await asyncio.sleep(0.01)
    with pytest.raises(ProviderError) as caught:
        await service.complete([{"role": "user", "content": "second"}], max_completion_tokens=10)
    assert caught.value.error_code == "concurrency_limit"
    await first
    metrics = await service.metrics()
    assert metrics["peak_in_flight"] == 1


@pytest.mark.asyncio
async def test_circuit_breaker_allows_half_open_recovery_probe():
    class FailsOnce:
        name = "flaky"
        model = "flaky-v1"

        def __init__(self):
            self.calls = 0

        async def complete(self, messages, *, temperature, max_completion_tokens):
            del messages, temperature, max_completion_tokens
            self.calls += 1
            if self.calls == 1:
                raise ProviderError("first call fails", status_code=503, retryable=False)
            return CompletionResult("recovered", self.model)

        async def stream(self, messages, *, temperature, max_completion_tokens):
            result = await self.complete(messages, temperature=temperature, max_completion_tokens=max_completion_tokens)
            yield result.content

    flaky = FailsOnce()
    wrapped = ResilientProvider(flaky, reliability(
        circuit_failure_threshold=1, circuit_recovery_seconds=0.01, max_retries=0,
    ))
    with pytest.raises(ProviderError):
        await wrapped.complete([], temperature=0, max_completion_tokens=10)
    await asyncio.sleep(0.02)
    result = await wrapped.complete([], temperature=0, max_completion_tokens=10)
    assert result.content == "recovered"
    assert (await wrapped.breaker.snapshot())["state"] == "closed"
