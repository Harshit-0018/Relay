from __future__ import annotations

import csv
import json
from pathlib import Path

from experiments.common import RESULT_COLUMNS, RESULTS_DIR, RESULTS_CSV, percentile
from experiments.retrieval_benchmark import SETTINGS, grade_answer
from experiments.run_load_benchmark import make_scenarios

ROOT = Path(__file__).resolve().parents[1]


def test_five_required_load_scenarios_are_defined():
    scenarios = make_scenarios()
    assert [item.scenario_id for item in scenarios] == [
        "steady", "burst", "sustained_overload", "per_minute_limit_halved", "daily_budget_exhausted"
    ]


def test_three_distinct_retrieval_configurations_are_defined():
    assert len(SETTINGS) >= 3
    assert len({item.setting_id for item in SETTINGS}) >= 3
    assert len({(item.chunk_size, item.top_k, item.rerank) for item in SETTINGS}) >= 3


def test_expected_term_and_citation_grade_is_deterministic():
    question = {
        "answerable": True,
        "expected_papers": ["1706.03762v7"],
        "evidence_pdf_pages": [1],
        "expected_terms": ["transformer", "attention"],
    }
    citation = "[Attention Is All You Need, arXiv:1706.03762v7, PDF p. 1, section: Abstract]"
    assert grade_answer(question, "Transformer uses attention.", [citation], False) == "correct"
    assert grade_answer(question, "Transformer uses attention.", [], False) == "wrong"
    unanswerable = {"answerable": False}
    assert grade_answer(unanswerable, "I cannot answer from these papers.", [], True) == "refused_correctly"
    assert grade_answer(unanswerable, "Here is a guess.", [], False) == "refused_wrongly"


def test_percentile_uses_linear_interpolation():
    assert percentile([0, 10, 20, 30], 50) == 15
    assert percentile([], 95) is None


def test_phase4_raw_csv_has_exact_required_columns_and_rows():
    assert RESULTS_CSV.exists()
    with RESULTS_CSV.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        assert reader.fieldnames == RESULT_COLUMNS
        rows = list(reader)
    standin_rows = [row for row in rows if row["source"] == "stand-in"]
    assert len(standin_rows) >= 100
    assert {row["scenario"] for row in rows} >= {
        "steady", "burst", "sustained_overload", "per_minute_limit_halved", "daily_budget_exhausted"
    }
    assert all(row["source"] in {"stand-in", "real"} for row in rows)
    assert all(row["status"] in {"ok", "rate_limited", "timeout", "error"} for row in rows)
    assert all(row["answer_grade"] == "" for row in standin_rows)


def test_load_metrics_contain_all_scenarios_and_outcomes():
    path = RESULTS_DIR / "scenario_metrics.json"
    assert path.exists()
    metrics = json.loads(path.read_text(encoding="utf-8"))
    assert len(metrics) == 5
    by_name = {row["scenario"]: row for row in metrics}
    assert by_name["sustained_overload"]["provider"]["rate_limited"] > 0
    assert by_name["per_minute_limit_halved"]["provider"]["rate_limited"] > 0
    assert by_name["daily_budget_exhausted"]["provider"]["rate_limited"] > 0


def test_traces_and_slow_request_breakdown_exist():
    trace_path = RESULTS_DIR / "traces.jsonl"
    slow_path = RESULTS_DIR / "slow_request_analysis.json"
    assert trace_path.exists() and trace_path.stat().st_size > 0
    assert slow_path.exists()
    slow = json.loads(slow_path.read_text(encoding="utf-8"))
    assert slow.get("request_id")
    assert slow["total_ms"] >= slow["waiting_ms"]


def test_real_provider_and_missing_paper_status_are_honestly_recorded():
    real = json.loads((RESULTS_DIR / "real_probe_status.json").read_text(encoding="utf-8"))
    retrieval = json.loads((RESULTS_DIR / "retrieval_eval_status.json").read_text(encoding="utf-8"))
    assert real["status"] in {"not_measured", "ready_not_run", "measured"}
    if real["status"] in {"not_measured", "ready_not_run"}:
        assert real["requests_attempted"] == 0
    assert isinstance(retrieval["pdfs_available"], bool)
    if not retrieval["pdfs_available"]:
        assert len(retrieval["missing_or_failed_settings"]) == 3


def test_report_tables_are_generated():
    for name in [
        "table_1_real_service_limits.csv", "table_2a_latency.csv", "table_2b_outcomes.csv",
        "table_3_retrieval.csv", "report_tables.md",
    ]:
        path = RESULTS_DIR / name
        assert path.exists() and path.stat().st_size > 0
