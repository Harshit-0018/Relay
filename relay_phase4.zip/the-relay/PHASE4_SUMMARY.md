# Phase 4 Summary — The Relay

## Completed in this build

- Five stand-in load scenarios executed.
- 116 request-level rows generated in project-root `results.csv` using the exact 12 assignment columns.
- Three retrieval configurations implemented and recorded.
- 20 evaluation questions retained (18 answerable, 2 unanswerable).
- Request traces, scenario metrics, aggregate metrics, four assignment tables and report-ready Markdown generated.
- Slowest successful request latency decomposed into queue wait, work before/after first token and retry wait.
- Phase 3 retry-amplification demo re-run and its result recorded.
- Cumulative test suite: 50 passed, 0 failed, 0 skipped.

## Load scenario outcomes

| Scenario | Requests | Succeeded | Rate-limited | Timeout/error |
|---|---:|---:|---:|---:|
| Steady traffic | 20 | 20 | 0 | 0 |
| Sudden burst | 24 | 24 | 0 | 0 |
| Sustained overload | 40 | 8 | 32 | 0 |
| Per-minute limit halved (10 RPM reference to 5 RPM) | 20 | 5 | 15 | 0 |
| Daily request budget exhausted (budget set to 4) | 12 | 4 | 8 | 0 |

All stand-in request rows have blank `answer_grade` by design: the simulator's response is synthetic and cannot be used to grade factual answer quality.

## Not measured / local actions required

- Real Groq requests, latency and response headers: no API key was configured; no real request was sent.
- Paper-backed retrieval quality and final answer quality: exact PDFs were unavailable in the build environment. The retrieval script records the three configurations as `not_measured` and includes commands to run after downloading the papers.
- Exact account-specific Groq limits and recovery behavior: must be confirmed in the account Limits page and measured with the opt-in probe. The documentation snapshot is in `docs/GROQ_LIMITS_SNAPSHOT.md`.

## Start here locally

See `docs/PHASE4.md` and the README. From the project root:

```powershell
python scripts/download_papers.py
python -m app.cli ingest
python -m experiments.run_load_benchmark
python -m experiments.retrieval_benchmark
python -m experiments.run_real_groq_probe
python -m experiments.build_report_tables
python -m pytest
```

For modest real Groq measurements, configure your own key in `.env`, check your current account quota, then explicitly run:

```powershell
python -m experiments.run_real_groq_probe --run --max-requests 3
```

For actual answer-quality evaluation across the three retrieval settings (up to 45 sequential calls):

```powershell
python -m experiments.retrieval_benchmark --with-groq --max-questions 15
```

Do not run the real evaluation when the account's available quota is low. The report tables are rebuilt with `python -m experiments.build_report_tables`.
