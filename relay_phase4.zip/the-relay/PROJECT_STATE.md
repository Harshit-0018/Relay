# Project State — The Relay

## Current phase

**Phase 4 implementation complete.** This cumulative codebase retains Phases 1–3 and adds experiment runners, raw measurements, traces, retrieval evaluation scaffolding and generated report tables. Phase 5 remains: final audit and the two-page report.

## Phase 1 — Implemented and retained

- Exact-version paper registry for `1706.03762v7`, `2410.00037v1` and `2507.07955v2`.
- Version-pinned arXiv PDF downloader with PDF-signature validation and SHA-256 manifest generation.
- PyMuPDF page extraction with 1-based physical PDF page metadata and conservative section detection.
- Page-bounded chunking with configurable character size/overlap and deterministic chunk IDs.
- Dependency-free BM25 retriever and callable `search_research_papers` tool.
- CLI commands for paper ingestion and retrieval search.
- 20 evaluation questions.

## Phase 2 — Implemented and retained

- FastAPI service with `/health`, `/v1/ask`, `/v1/ask/stream` and `/docs`.
- Groq Chat Completions adapter and deterministic offline demo provider.
- Actual retrieval-tool invocation from the answer pipeline.
- Evidence-only prompt, bounded context and source/page citation labels.
- Citation provenance checks, bounded correction and refusal paths.
- Verified-before-delivery streaming: full draft is buffered and checked before SSE delivery.

## Phase 3 — Implemented and retained

- Configurable in-process stand-in service and standalone OpenAI-compatible simulator API.
- Latency/jitter, slow tails, load slowdown, deterministic/random failures, timeouts and streaming.
- Simulated RPM, TPM, requests/day, tokens/day and concurrency limits.
- Bounded admission queue, deadlines, retries, backoff, Retry-After and circuit breaker.
- Cancellation propagation and reliability metrics.
- Retry amplification demonstration.

## Phase 4 — Implemented

- Five load scenarios: steady, burst, sustained overload, per-minute limit halved, daily budget exhausted.
- Three retrieval configurations: 700/80/top-3/no rerank; 1200/180/top-5/no rerank; 1800/260/top-8/lexical rerank.
- 20-question evaluation dataset retained.
- Async stream-based stand-in load runner with queue-wait, TTFT and total-latency measurement.
- Exact assignment `results.csv` schema; one row per request.
- JSONL timing traces and per-scenario simulator/admission metrics.
- Optional opt-in real Groq probe (hard cap: five requests) that captures available rate-limit headers.
- Optional paper-backed Groq answer evaluation across all three retrieval settings with conservative pacing and an inspectable grading heuristic.
- Retrieval evidence-hit diagnostics against the question bank's expected papers, pages and terms.
- Automated generators for Tables 1, 2a, 2b and 3; generated report-ready Markdown.
- Slowest successful stand-in request latency breakdown.

## Phase 4 — Actual execution record

Executed in the build environment on 2026-11-12:

- Stand-in requests: **116 total**, all recorded in project-root `results.csv`.
- `steady`: 20/20 succeeded.
- `burst`: 24/24 succeeded.
- `sustained_overload`: 8/40 succeeded; 32/40 rate-limited.
- `per_minute_limit_halved`: 5/20 succeeded; 15/20 rate-limited (configured baseline reference 10 RPM, experimental cap 5 RPM).
- `daily_budget_exhausted`: 4/12 succeeded; 8/12 rate-limited (simulator daily request budget configured to four).
- Statuses in all these runs were `ok` or `rate_limited`; no timeout/error was observed in the five configured load scenarios.
- Full tests after Phase 4 additions: **50 passed, 0 failed, 0 skipped**.
- Python compile check: passed.
- Phase 3 retry-storm demonstration re-run: `no_retry_rate_limited=0`, `with_retry_rate_limited=1` under the constrained demonstration budget.

## Not measured in this build

- No `.env` and no `GROQ_API_KEY` were present; no real Groq request was attempted.
- Original paper PDFs were not present. A network download attempt failed in this build environment. Therefore no paper-backed retrieval configuration could be evaluated here.
- No final LLM answer-quality grades, real TTFT, real token counts, or live reset/recovery times were generated.
- The retrieval script records these as `not measured`, and has local commands to run when the PDFs and key are available.

## Groq documentation snapshot

On 2026-11-12, the public Groq rate-limit docs' Free Plan table for `openai/gpt-oss-20b` displayed 30 RPM, 1,000 RPD, 8,000 TPM and 200,000 TPD. Groq says exact organization limits can vary; these are documentation values, not account measurements. The public GPT-OSS 20B rate card displayed $0.075/M input and $0.30/M output tokens. Equivalent cost figures in Phase 4 are estimates, not cash charged to a free-tier account. See `docs/GROQ_LIMITS_SNAPSHOT.md`.

## Outputs added in Phase 4

- `results.csv`
- `experiments/run_load_benchmark.py`
- `experiments/retrieval_benchmark.py`
- `experiments/run_real_groq_probe.py`
- `experiments/build_report_tables.py`
- `experiments/common.py`
- `experiments/results/standin_load_results.csv`
- `experiments/results/traces.jsonl`
- `experiments/results/scenario_metrics.json`
- `experiments/results/metrics.json`
- `experiments/results/retrieval_settings.csv`
- `experiments/results/retrieval_question_results.csv`
- `experiments/results/real_probe_status.json`
- `experiments/results/slow_request_analysis.json`
- `experiments/results/table_1_real_service_limits.csv`
- `experiments/results/table_2a_latency.csv`
- `experiments/results/table_2b_outcomes.csv`
- `experiments/results/table_3_retrieval.csv`
- `experiments/results/report_tables.md`
- `docs/PHASE4.md`
- `docs/GROQ_LIMITS_SNAPSHOT.md`

## Approximation boundaries

- The stand-in is not an LLM; synthetic responses are not used for factual answer grading.
- Simulator quota windows are process-local fixed-window approximations.
- Simulator token counts use a character-based estimate, not Groq's tokenizer.
- Stand-in load tests run through a benchmark admission gate; it records queue wait, but its scheduling is not a strict multi-user fair queue.
- Percentiles are computed over successful requests only; sample size is reported.
- p95/p99 from small synthetic samples are descriptive and should not be treated as high-confidence service-level estimates.
- Retrieval evidence-hit rate uses expected paper/page/term annotations; it is a retrieval diagnostic, not semantic answer correctness.
- The optional Groq answer grader is a heuristic based on expected terms and exact paper/page citation; grades need manual review.
- Citation validation checks provenance, not full semantic entailment.
- Real rate limits, concurrency, latency and recovery remain account-specific and require the local opt-in probe.

## Next phase

Phase 5: final audit, reconcile all tables against `results.csv`, produce the required two-page report with the exact assignment headings, complete packaging and final VS Code/Windows run instructions.
