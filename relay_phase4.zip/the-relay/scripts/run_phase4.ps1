param(
    [switch]$RunGroqProbe,
    [switch]$RunGroqEvaluation,
    [int]$MaxQuestions = 15
)

Write-Host 'The Relay - Phase 4 experiments' -ForegroundColor Cyan
python -m experiments.run_load_benchmark
if ($LASTEXITCODE -ne 0) { Write-Warning 'Stand-in load benchmark returned a failure; continuing.' }

python -m experiments.retrieval_benchmark
if ($LASTEXITCODE -ne 0) { Write-Warning 'Retrieval benchmark returned a failure; continuing.' }

if ($RunGroqProbe) {
    python -m experiments.run_real_groq_probe --run --max-requests 3
    if ($LASTEXITCODE -ne 0) { Write-Warning 'Real Groq probe returned a failure; check real_probe_status.json.' }
} else {
    Write-Host 'Real Groq probe not requested; no real API requests sent.'
}

if ($RunGroqEvaluation) {
    python -m experiments.retrieval_benchmark --with-groq --max-questions $MaxQuestions
    if ($LASTEXITCODE -ne 0) { Write-Warning 'Real answer evaluation returned a failure; inspect retrieval_eval_status.json.' }
} else {
    Write-Host 'Real LLM answer-quality evaluation not requested.'
}

python -m experiments.build_report_tables
if ($LASTEXITCODE -ne 0) { Write-Warning 'Report-table generation returned a failure.' }
Write-Host 'Phase 4 command sequence finished. Review experiments/results/ and results.csv.' -ForegroundColor Green
