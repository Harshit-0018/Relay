"""Small deterministic demo: retrying a minute-limited provider increases rejected calls."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.providers.base import ProviderError
from app.providers.standin_provider import StandInProvider
from app.reliability.config import ReliabilityConfig
from app.reliability.resilient_provider import ResilientProvider
from simulator.service import SimulatedModelService, SimulatorConfig


async def run(retries: int) -> dict:
    service = SimulatedModelService(SimulatorConfig(
        base_latency_seconds=0.001, latency_jitter_seconds=0, slow_tail_probability=0,
        fail_first_n=1, rpm_limit=2, tpm_limit=10000, requests_per_day=100, tokens_per_day=100000,
        max_concurrent=10, random_seed=13,
    ))
    provider = ResilientProvider(StandInProvider(service), ReliabilityConfig(
        max_in_flight=10, max_queue=10, provider_deadline_seconds=0.5,
        max_retries=retries, retry_base_seconds=0.001, retry_max_seconds=0.002,
        circuit_failure_threshold=5,
    ))
    for prompt in ("first request", "second request"):
        try:
            await provider.complete([{"role": "user", "content": prompt}], temperature=0, max_completion_tokens=20)
        except ProviderError:
            pass
    return await service.metrics()


async def main() -> None:
    no_retry = await run(0)
    with_retry = await run(2)
    print({
        "no_retry_rate_limited": no_retry["rate_limited"],
        "with_retry_rate_limited": with_retry["rate_limited"],
        "no_retry_upstream_requests": no_retry["requests"],
        "with_retry_upstream_requests": with_retry["requests"],
    })


if __name__ == "__main__":
    asyncio.run(main())
