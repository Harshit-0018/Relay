from app.retrieval.text_utils import normalize_whitespace, tokenize


def test_tokenize_is_case_insensitive():
    assert tokenize("Attention Is ALL You Need") == ["attention", "is", "all", "you", "need"]


def test_normalize_whitespace_removes_linebreak_hyphenation():
    assert normalize_whitespace("transfor-\nmer   model") == "transformer model"
