from app.retrieval.chunking import _cut_text, build_chunks
from app.retrieval.schemas import PaperPage


def page(text: str) -> PaperPage:
    return PaperPage("p", "Title", "1234.00001", 1, "p.pdf", 3, None, "1 Introduction", text)


def test_chunking_preserves_paper_and_page_metadata():
    chunks = build_chunks([page("1 Introduction\n\n" + ("Attention supports parallel computation. " * 30))], chunk_size=220, overlap=30)
    assert len(chunks) > 1
    assert all(chunk.arxiv_id == "1234.00001" for chunk in chunks)
    assert all(chunk.pdf_page == 3 for chunk in chunks)
    assert len({chunk.chunk_id for chunk in chunks}) == len(chunks)


def test_cut_text_rejects_invalid_overlap():
    try:
        _cut_text("x" * 500, chunk_size=200, overlap=200)
    except ValueError:
        return
    raise AssertionError("Expected ValueError")
