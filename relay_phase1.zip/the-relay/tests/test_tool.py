from pathlib import Path

from app.retrieval.schemas import Chunk
from app.retrieval.store import save_chunks
from app.retrieval.tool import PaperSearchTool


def test_paper_search_tool_returns_citation_metadata(tmp_path: Path):
    chunks = [Chunk(
        chunk_id="abc123", paper_id="paper", title="Attention Is All You Need",
        arxiv_id="1706.03762", version=7, pdf_filename="1706.03762v7.pdf",
        pdf_page=2, printed_page=None, section="1 Introduction",
        chunk_index_on_page=0, text="The Transformer relies entirely on attention and removes recurrence.",
    )]
    chunk_file = tmp_path / "chunks.jsonl"
    save_chunks(chunk_file, chunks)
    tool = PaperSearchTool(chunk_file)
    result = tool(query="Transformer attention", top_k=2)
    assert result["tool"] == "search_research_papers"
    assert result["result_count"] == 1
    assert result["results"][0]["arxiv_id"] == "1706.03762"
    assert result["results"][0]["version"] == 7
    assert result["results"][0]["pdf_page"] == 2


def test_paper_search_tool_rejects_empty_query(tmp_path: Path):
    chunk_file = tmp_path / "chunks.jsonl"
    save_chunks(chunk_file, [])
    tool = PaperSearchTool(chunk_file)
    try:
        tool(query="   ")
    except ValueError:
        return
    raise AssertionError("Expected ValueError")
