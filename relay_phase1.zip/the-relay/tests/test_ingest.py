import json
from pathlib import Path

import fitz

from app.retrieval.ingest import extract_pdf_pages
from app.retrieval.schemas import PaperMetadata


def test_extract_pdf_pages_keeps_one_based_page_number(tmp_path: Path):
    pdf_path = tmp_path / "sample.pdf"
    document = fitz.open()
    page = document.new_page()
    page.insert_text((72, 45), "Sample Paper Running Header")
    page.insert_text((72, 72), "1 Introduction")
    page.insert_text((72, 100), "A small test paragraph about retrieval and attention.")
    document.save(pdf_path)
    document.close()

    metadata = PaperMetadata("sample", "Sample", "9999.00001", 1, "sample.pdf", "https://example.invalid/sample.pdf")
    pages = extract_pdf_pages(pdf_path, metadata)
    assert len(pages) == 1
    assert pages[0].pdf_page == 1
    assert pages[0].section == "1 Introduction"
    assert "attention" in pages[0].text.lower()
