import json
from pathlib import Path


def test_evaluation_dataset_has_at_least_15_unique_questions():
    path = Path(__file__).resolve().parents[1] / "data" / "evaluation_questions" / "questions.jsonl"
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert len(rows) >= 15
    assert len({row["question_id"] for row in rows}) == len(rows)
    assert any(row["answerable"] is False for row in rows)
