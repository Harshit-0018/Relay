from __future__ import annotations

import hashlib
from app.retrieval.schemas import Chunk, PaperPage
from app.retrieval.text_utils import normalize_whitespace
from app.retrieval.section_utils import detect_section_heading

def _split_sections(text: str, initial_section: str | None) -> list[tuple[str | None, str]]:
    current = initial_section
    segments: list[tuple[str | None, list[str]]] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            if segments:
                segments[-1][1].append("")
            continue
        heading = detect_section_heading(stripped)
        if heading:
            current = heading
            segments.append((current, [stripped]))
            continue
        if not segments:
            segments.append((current, []))
        segments[-1][1].append(stripped)
    return [(section, normalize_whitespace("\n".join(lines))) for section, lines in segments if normalize_whitespace("\n".join(lines))]


def _cut_text(text: str, chunk_size: int, overlap: int) -> list[str]:
    if chunk_size < 100:
        raise ValueError("chunk_size must be at least 100 characters")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and smaller than chunk_size")
    text = normalize_whitespace(text)
    if len(text) <= chunk_size:
        return [text] if text else []

    chunks: list[str] = []
    start = 0
    while start < len(text):
        hard_end = min(len(text), start + chunk_size)
        end = hard_end
        if hard_end < len(text):
            floor = start + int(chunk_size * 0.60)
            candidates = [text.rfind(mark, floor, hard_end) for mark in (". ", "? ", "! ", " ")]
            best = max(candidates)
            if best > start:
                end = best + (1 if text[best:best + 1] == " " else 0)
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= len(text):
            break
        next_start = max(start + 1, end - overlap)
        # Avoid beginning in the middle of a word.
        while next_start < end and not text[next_start].isspace():
            next_start += 1
        start = next_start
    return chunks


def build_chunks(pages: list[PaperPage], chunk_size: int = 1200, overlap: int = 180) -> list[Chunk]:
    chunks: list[Chunk] = []
    for page in pages:
        local_index = 0
        for section, segment_text in _split_sections(page.text, page.section):
            for piece in _cut_text(segment_text, chunk_size, overlap):
                identity = "|".join((page.paper_id, str(page.version), str(page.pdf_page), str(local_index), piece))
                chunk_id = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]
                chunks.append(Chunk(
                    chunk_id=chunk_id,
                    paper_id=page.paper_id,
                    title=page.title,
                    arxiv_id=page.arxiv_id,
                    version=page.version,
                    pdf_filename=page.pdf_filename,
                    pdf_page=page.pdf_page,
                    printed_page=page.printed_page,
                    section=section,
                    chunk_index_on_page=local_index,
                    text=piece,
                ))
                local_index += 1
    return chunks
