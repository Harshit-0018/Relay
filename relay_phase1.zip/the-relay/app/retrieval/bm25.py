from __future__ import annotations

import math
from collections import Counter

from app.retrieval.schemas import Chunk, SearchResult
from app.retrieval.text_utils import tokenize


class BM25Retriever:
    """Small dependency-free BM25 implementation for the assignment's paper library."""

    def __init__(self, chunks: list[Chunk], k1: float = 1.5, b: float = 0.75) -> None:
        if k1 <= 0 or not 0 <= b <= 1:
            raise ValueError("BM25 requires k1 > 0 and 0 <= b <= 1")
        self.chunks = chunks
        self.k1 = k1
        self.b = b
        self.tokens = [tokenize(chunk.text) for chunk in chunks]
        self.term_freqs = [Counter(tokens) for tokens in self.tokens]
        self.doc_lengths = [len(tokens) for tokens in self.tokens]
        self.avg_doc_length = sum(self.doc_lengths) / max(1, len(self.doc_lengths))
        self.doc_freqs: Counter[str] = Counter()
        for frequencies in self.term_freqs:
            self.doc_freqs.update(frequencies.keys())

    def search(self, query: str, top_k: int = 5) -> list[SearchResult]:
        if top_k <= 0:
            raise ValueError("top_k must be positive")
        query_terms = tokenize(query)
        if not query_terms or not self.chunks:
            return []
        query_counts = Counter(query_terms)
        n_docs = len(self.chunks)
        scores: list[tuple[int, float]] = []
        for doc_index, frequencies in enumerate(self.term_freqs):
            doc_length = self.doc_lengths[doc_index]
            score = 0.0
            for term, qf in query_counts.items():
                tf = frequencies.get(term, 0)
                if not tf:
                    continue
                df = self.doc_freqs.get(term, 0)
                idf = math.log(1 + (n_docs - df + 0.5) / (df + 0.5))
                denominator = tf + self.k1 * (1 - self.b + self.b * doc_length / max(1.0, self.avg_doc_length))
                score += idf * (tf * (self.k1 + 1) / denominator) * (1 + math.log(qf))
            if score > 0:
                scores.append((doc_index, score))
        scores.sort(key=lambda pair: pair[1], reverse=True)
        return [SearchResult(self.chunks[index], score) for index, score in scores[:top_k]]
