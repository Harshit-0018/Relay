from __future__ import annotations

from pathlib import Path
from typing import Any

from app.retrieval.bm25 import BM25Retriever
from app.retrieval.store import load_chunks


class PaperSearchTool:
    """Callable retrieval tool with stable input/output fields for later pipeline integration."""

    name = "search_research_papers"
    description = "Search the approved research-paper library and return passages with source metadata."

    def __init__(self, chunks_path: Path) -> None:
        self.chunks = load_chunks(chunks_path)
        self.retriever = BM25Retriever(self.chunks)

    def __call__(self, query: str, top_k: int = 5) -> dict[str, Any]:
        if not isinstance(query, str) or not query.strip():
            raise ValueError("query must be a non-empty string")
        results = self.retriever.search(query, top_k=top_k)
        return {
            "tool": self.name,
            "query": query,
            "results": [result.to_dict() for result in results],
            "result_count": len(results),
            "citation_format": "[Title, arXiv:{arxiv_id}v{version}, PDF p. {pdf_page}, section: {section}]",
        }
