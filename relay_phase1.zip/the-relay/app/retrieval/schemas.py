from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(slots=True)
class PaperMetadata:
    paper_id: str
    title: str
    arxiv_id: str
    version: int
    pdf_filename: str
    pdf_url: str


@dataclass(slots=True)
class PaperPage:
    paper_id: str
    title: str
    arxiv_id: str
    version: int
    pdf_filename: str
    pdf_page: int  # 1-based physical page number in the downloaded PDF
    printed_page: int | None
    section: str | None
    text: str


@dataclass(slots=True)
class Chunk:
    chunk_id: str
    paper_id: str
    title: str
    arxiv_id: str
    version: int
    pdf_filename: str
    pdf_page: int
    printed_page: int | None
    section: str | None
    chunk_index_on_page: int
    text: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class SearchResult:
    chunk: Chunk
    score: float

    def to_dict(self) -> dict[str, Any]:
        result = self.chunk.to_dict()
        result["score"] = self.score
        return result
