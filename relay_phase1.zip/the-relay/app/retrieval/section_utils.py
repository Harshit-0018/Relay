from __future__ import annotations

import re

NUMBERED_HEADING_RE = re.compile(r"^(?:\d+(?:\.\d+)*|[A-Z](?:\.\d+)?)\s+\S")
UNNUMBERED_HEADINGS = {
    "abstract", "references", "acknowledgements", "acknowledgments", "appendix"
}


def detect_section_heading(line: str) -> str | None:
    """Return a conservative section-heading match; ignore running paper headers."""
    candidate = " ".join(line.strip().split())
    if not candidate or len(candidate) > 105 or len(candidate.split()) > 14:
        return None
    if candidate.lower() in UNNUMBERED_HEADINGS:
        return candidate.title()
    match = NUMBERED_HEADING_RE.match(candidate)
    if not match:
        return None
    if candidate.endswith((".", ";", ",")):
        return None
    label = re.sub(r"^(?:\d+(?:\.\d+)*|[A-Z](?:\.\d+)?)\s+", "", candidate)
    first_letter = next((char for char in label if char.isalpha()), "")
    return candidate if first_letter and first_letter.isupper() else None
