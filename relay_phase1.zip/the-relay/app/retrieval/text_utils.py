from __future__ import annotations

import re

TOKEN_RE = re.compile(r"[a-zA-Z0-9]+(?:['’][a-zA-Z0-9]+)?")


def tokenize(text: str) -> list[str]:
    """Simple deterministic tokenizer; deliberately dependency-free."""
    return [token.lower() for token in TOKEN_RE.findall(text)]


def normalize_whitespace(text: str) -> str:
    text = text.replace("\u00ad", "")  # soft hyphen from PDF extraction
    text = re.sub(r"(?<=\w)-\s*\n\s*(?=\w)", "", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
