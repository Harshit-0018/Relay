from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import fitz

from app.retrieval.schemas import PaperMetadata, PaperPage
from app.retrieval.text_utils import normalize_whitespace
from app.retrieval.section_utils import detect_section_heading

def extract_pdf_pages(pdf_path: Path, metadata: PaperMetadata) -> list[PaperPage]:
    """Extract text with 1-based PDF page numbers and best-effort section labels."""
    if not pdf_path.exists():
        raise FileNotFoundError(f"Paper PDF not found: {pdf_path}. Run scripts/download_papers.py first.")

    pages: list[PaperPage] = []
    active_section: str | None = None
    with fitz.open(pdf_path) as document:
        if document.page_count == 0:
            raise ValueError(f"PDF has no pages: {pdf_path}")
        for page_index, page in enumerate(document):
            raw = page.get_text("text", sort=True)
            raw = normalize_whitespace(raw)
            if not raw:
                continue

            lines = raw.splitlines()
            found_heading = next((heading for line in lines[:35] if (heading := detect_section_heading(line))), None)
            if found_heading:
                active_section = found_heading

            # PyMuPDF does not reliably expose the printed page number for all layouts.
            # Keep physical PDF page number authoritative and printed_page explicitly unknown.
            pages.append(PaperPage(
                paper_id=metadata.paper_id,
                title=metadata.title,
                arxiv_id=metadata.arxiv_id,
                version=metadata.version,
                pdf_filename=metadata.pdf_filename,
                pdf_page=page_index + 1,
                printed_page=None,
                section=active_section,
                text=raw,
            ))
    return pages


def load_registry(registry_path: Path) -> list[PaperMetadata]:
    payload = json.loads(registry_path.read_text(encoding="utf-8"))
    return [PaperMetadata(**entry) for entry in payload["papers"]]


def write_jsonl(path: Path, rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
