"""Paper ingestion and retrieval components."""
