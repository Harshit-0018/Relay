from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.retrieval.chunking import build_chunks
from app.retrieval.ingest import extract_pdf_pages, load_registry, write_jsonl
from app.retrieval.store import load_chunks, save_chunks
from app.retrieval.bm25 import BM25Retriever

ROOT = Path(__file__).resolve().parents[1]
PAPERS_DIR = ROOT / "data" / "papers"
PROCESSED_DIR = ROOT / "data" / "processed"
REGISTRY = PAPERS_DIR / "paper_registry.json"


def command_ingest(args: argparse.Namespace) -> int:
    metadata = load_registry(REGISTRY)
    all_pages = []
    all_chunks = []
    missing = []
    for paper in metadata:
        pdf_path = PAPERS_DIR / paper.pdf_filename
        if not pdf_path.exists():
            missing.append(paper.pdf_filename)
            continue
        pages = extract_pdf_pages(pdf_path, paper)
        chunks = build_chunks(pages, chunk_size=args.chunk_size, overlap=args.overlap)
        all_pages.extend(pages)
        all_chunks.extend(chunks)
        print(f"INGESTED {paper.arxiv_id}v{paper.version}: {len(pages)} pages, {len(chunks)} chunks")
    if missing:
        raise SystemExit("Missing paper PDFs: " + ", ".join(missing) + ". Run `python scripts/download_papers.py` first.")
    write_jsonl(PROCESSED_DIR / "pages.jsonl", [page.__dict__ if hasattr(page, "__dict__") else {
        "paper_id": page.paper_id, "title": page.title, "arxiv_id": page.arxiv_id,
        "version": page.version, "pdf_filename": page.pdf_filename, "pdf_page": page.pdf_page,
        "printed_page": page.printed_page, "section": page.section, "text": page.text,
    } for page in all_pages])
    save_chunks(PROCESSED_DIR / "chunks.jsonl", all_chunks)
    manifest = {
        "chunk_size_chars": args.chunk_size,
        "overlap_chars": args.overlap,
        "paper_count": len(metadata),
        "page_count": len(all_pages),
        "chunk_count": len(all_chunks),
        "citation_page_basis": "1-based physical PDF page number",
    }
    (PROCESSED_DIR / "ingestion_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"WROTE {PROCESSED_DIR / 'chunks.jsonl'} ({len(all_chunks)} chunks)")
    return 0


def command_search(args: argparse.Namespace) -> int:
    chunks = load_chunks(PROCESSED_DIR / "chunks.jsonl")
    retriever = BM25Retriever(chunks)
    results = retriever.search(args.query, args.top_k)
    if not results:
        print("No matching passages found.")
        return 0
    for rank, result in enumerate(results, 1):
        c = result.chunk
        print(f"\n[{rank}] score={result.score:.4f} | {c.title} | arXiv:{c.arxiv_id}v{c.version} | PDF p.{c.pdf_page} | {c.section or 'section unavailable'}")
        print(c.text[:args.preview_chars])
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="the-relay", description="Phase 1 paper ingestion and retrieval tools")
    subparsers = parser.add_subparsers(dest="command", required=True)
    ingest = subparsers.add_parser("ingest", help="Extract papers and build page-aware chunks")
    ingest.add_argument("--chunk-size", type=int, default=1200)
    ingest.add_argument("--overlap", type=int, default=180)
    ingest.set_defaults(func=command_ingest)
    search = subparsers.add_parser("search", help="Search ingested paper chunks with BM25")
    search.add_argument("query")
    search.add_argument("--top-k", type=int, default=5)
    search.add_argument("--preview-chars", type=int, default=900)
    search.set_defaults(func=command_search)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
