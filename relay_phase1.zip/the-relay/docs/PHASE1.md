# Phase 1 Implementation Notes

## Retrieval path

`arXiv versioned PDF -> PyMuPDF page extraction -> page-bounded chunking -> JSONL chunk store -> BM25Retriever -> PaperSearchTool`

## Citation identity

Each chunk retains `title`, `arxiv_id`, `version`, `pdf_filename`, `pdf_page`, `printed_page`, and `section`. `pdf_page` is the 1-based physical page index from the PDF. It is used as the stable citation location because printed page labels can be absent or offset.

## Retrieval implementation

BM25 is implemented locally to avoid an extra dependency and make the Phase 1 baseline reproducible. It is a lexical baseline, not a claim of optimal retrieval. Dense retrieval and reranking can be compared in the later retrieval experiments.

## Evaluation dataset

`data/evaluation_questions/questions.jsonl` contains 20 initial records. The expected content is based on the specified paper versions. It includes questions outside the paper library to test refusal behavior later. The expected pages are initial PDF-page hints and should be confirmed against extracted chunks during full evaluation.
