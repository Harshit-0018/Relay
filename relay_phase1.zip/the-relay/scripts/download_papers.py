from __future__ import annotations

import hashlib
import json
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAPERS_DIR = ROOT / "data" / "papers"
REGISTRY_PATH = PAPERS_DIR / "paper_registry.json"
USER_AGENT = "TheRelayAssignment/1.0 (research-paper retrieval coursework)"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download(url: str, destination: Path, attempts: int = 3) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    temporary = destination.with_suffix(destination.suffix + ".part")
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            with urllib.request.urlopen(request, timeout=45) as response, temporary.open("wb") as output:
                content_type = response.headers.get("Content-Type", "")
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    output.write(block)
            if temporary.stat().st_size < 10_000:
                raise RuntimeError(f"Downloaded file is unexpectedly small ({temporary.stat().st_size} bytes)")
            with temporary.open("rb") as handle:
                if handle.read(5) != b"%PDF-":
                    raise RuntimeError("Response is not a PDF; check the arXiv version URL or network proxy")
            temporary.replace(destination)
            return
        except Exception as exc:  # network errors should not kill the whole environment setup silently
            last_error = exc
            temporary.unlink(missing_ok=True)
            if attempt < attempts:
                time.sleep(attempt * 2)
    raise RuntimeError(f"Failed to download {url} after {attempts} attempts: {last_error}")


def main() -> int:
    PAPERS_DIR.mkdir(parents=True, exist_ok=True)
    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    manifest_entries = []
    failures = []
    for paper in registry["papers"]:
        destination = PAPERS_DIR / paper["pdf_filename"]
        try:
            if not destination.exists():
                print(f"Downloading {paper['title']} ({paper['arxiv_id']}v{paper['version']})")
                download(paper["pdf_url"], destination)
            else:
                with destination.open("rb") as handle:
                    if handle.read(5) != b"%PDF-":
                        raise RuntimeError(f"Existing file is not a PDF: {destination}")
            entry = {
                "paper_id": paper["paper_id"],
                "title": paper["title"],
                "arxiv_id": paper["arxiv_id"],
                "version": paper["version"],
                "url": paper["pdf_url"],
                "filename": paper["pdf_filename"],
                "size_bytes": destination.stat().st_size,
                "sha256": sha256_file(destination),
                "verified_at_utc": datetime.now(timezone.utc).isoformat(),
            }
            manifest_entries.append(entry)
            print(f"OK {destination.name} | {entry['size_bytes']} bytes | sha256={entry['sha256']}")
        except Exception as exc:
            failures.append((paper["pdf_filename"], str(exc)))
            print(f"FAILED {paper['pdf_filename']}: {exc}", file=sys.stderr)
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "papers_downloaded_or_verified": manifest_entries,
        "failures": [{"filename": name, "error": error} for name, error in failures],
    }
    (PAPERS_DIR / "download_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    if failures:
        print(f"\nCompleted with {len(failures)} download failure(s). See data/papers/download_manifest.json.")
        return 1
    print("\nAll exact-version PDFs are present and checksum-recorded.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
