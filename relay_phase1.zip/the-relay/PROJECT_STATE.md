# Project State — The Relay

## Current phase
Phase 1 complete: paper ingestion and retrieval foundation.

## Implemented
- Exact-version paper registry for `1706.03762v7`, `2410.00037v1` and `2507.07955v2`.
- Version-pinned arXiv PDF downloader with PDF-signature validation and SHA-256 manifest generation.
- PyMuPDF page extraction with 1-based physical PDF page metadata and conservative best-effort section detection.
- Page-bounded chunking with configurable character size/overlap and deterministic chunk IDs.
- Dependency-free BM25 retriever and callable `search_research_papers` tool with source metadata.
- CLI commands for paper ingestion and retrieval search.
- 20 initial evaluation questions (18 answerable prompts and 2 out-of-library refusal prompts).
- Unit tests and a synthetic end-to-end test run.

## Verification
- 10 tests passed, 0 failed, 0 skipped.
- Python compilation passed.
- CLI help passed.
- Synthetic PDF ingestion and search passed.
- See `tests/TEST_STATUS.md` for exact environment and commands.

## Paper downloads
The exact versioned URLs are recorded in `data/papers/paper_registry.json`. The PDFs are not embedded in this ZIP because the build environment could not resolve `arxiv.org` during download. Run `python scripts/download_papers.py` locally before ingestion. The downloader records exact file sizes and SHA-256 checksums.

## Known limitations
- Printed page labels are not parsed reliably; `pdf_page` stores the 1-based physical PDF page index and is the current citation basis.
- Section detection is heuristic and best-effort.
- Retrieval is lexical BM25 only in Phase 1; dense retrieval, reranking and retrieval configuration comparisons are deferred to Phase 4.
- Evaluation expected-page hints are initial references and should be checked against the extracted PDFs during the full evaluation run.

## Next phase
Phase 2: answer-generation pipeline, FastAPI, Groq provider abstraction, citation/evidence verification, refusal and streaming.
